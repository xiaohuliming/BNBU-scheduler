const STORAGE_KEY = 'bnbu-course-helper-config-v1';
const DEFAULT_CONFIG = {
  enabled: false,
  targets: '',
  startAt: '',
  endAt: '',
  minInterval: 0.5,
  maxInterval: 0.5,
  submitTimeout: 10,
  allowWaiting: false,
  autoConfirm: true,
  directSubmit: true,
  notify: true,
  collapsed: false
};

const fields = {
  targets: document.querySelector('#targets'),
  startAt: document.querySelector('#start-at'),
  endAt: document.querySelector('#end-at'),
  minInterval: document.querySelector('#min-interval'),
  maxInterval: document.querySelector('#max-interval'),
  submitTimeout: document.querySelector('#submit-timeout'),
  allowWaiting: document.querySelector('#allow-waiting'),
  autoConfirm: document.querySelector('#auto-confirm'),
  directSubmit: document.querySelector('#direct-submit'),
  notify: document.querySelector('#notify')
};

const startButton = document.querySelector('#start');
const stopButton = document.querySelector('#stop');
const saveButton = document.querySelector('#save');
const statePill = document.querySelector('#run-state');
const statusCard = document.querySelector('#status-card');
const statusText = document.querySelector('#status-text');
const countdown = document.querySelector('#countdown');
const formError = document.querySelector('#form-error');

let activeTabId = null;
let connected = false;

startButton.addEventListener('click', () => runAction('start-monitoring'));
stopButton.addEventListener('click', () => runAction('stop-monitoring'));
saveButton.addEventListener('click', () => runAction('apply-config'));

initialize();

function classifyMisPage(value) {
  try {
    const url = new URL(value);
    if (url.protocol !== 'https:' || url.port ||
        !['mis.bnbu.edu.cn', 'mis.uic.edu.cn'].includes(url.hostname)) return 'unsupported';
    const path = url.pathname.toLowerCase();
    if (path.startsWith('/mis/student/es/')) return 'selection';
    if (path.startsWith('/mis/student/as/')) return 'add-drop';
    return 'unsupported';
  } catch (_) {
    return 'unsupported';
  }
}

async function initialize() {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  fillForm({ ...DEFAULT_CONFIG, ...(stored[STORAGE_KEY] || {}) });

  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const activeTab = tabs[0];
  const pageKind = classifyMisPage(activeTab && activeTab.url);
  if (pageKind !== 'selection') {
    showDisconnected(pageKind === 'add-drop'
      ? '当前是加减课页面，本版暂未适配搜索与 Add 流程，不会执行加课或退课。请使用普通选课模块。'
      : '请先打开 BNBU MIS 普通选课页面。支持 mis.bnbu.edu.cn 和 mis.uic.edu.cn。');
    return;
  }

  activeTabId = activeTab.id;
  try {
    const state = await chrome.tabs.sendMessage(activeTabId, { type: 'get-state' });
    if (state && state.config) fillForm({ ...DEFAULT_CONFIG, ...state.config });
    updateStatus(state);
  } catch (_) {
    showDisconnected('扩展尚未注入页面，请刷新一次 MIS 选课页。');
  }
}

async function runAction(type) {
  formError.textContent = '';
  if (!activeTabId) {
    showDisconnected('请打开或刷新 BNBU MIS 选课页面。');
    return;
  }

  const config = readForm();
  const validationError = validateConfig(config);
  if (type !== 'stop-monitoring' && validationError) {
    formError.textContent = validationError;
    return;
  }

  setBusy(true);
  try {
    if (type !== 'stop-monitoring') {
      await chrome.storage.local.set({ [STORAGE_KEY]: config });
    }
    const response = await chrome.tabs.sendMessage(activeTabId, { type, config });
    if (!response || response.ok === false) {
      throw new Error(response && response.message ? response.message : '操作失败');
    }
    const state = await chrome.tabs.sendMessage(activeTabId, { type: 'get-state' });
    updateStatus(state);
  } catch (error) {
    showDisconnected(`无法连接页面：${error.message}`);
  } finally {
    setBusy(false);
  }
}

function readForm() {
  return {
    ...DEFAULT_CONFIG,
    targets: fields.targets.value.trim(),
    startAt: fields.startAt.value,
    endAt: fields.endAt.value,
    minInterval: clampNumber(fields.minInterval.value, 0.5, 3600, 5, 0.1),
    maxInterval: clampNumber(fields.maxInterval.value, 0.5, 3600, 8, 0.1),
    submitTimeout: clampNumber(fields.submitTimeout.value, 10, 180, 45),
    allowWaiting: fields.allowWaiting.checked,
    autoConfirm: fields.autoConfirm.checked,
    directSubmit: fields.directSubmit.checked,
    notify: fields.notify.checked
  };
}

function fillForm(config) {
  fields.targets.value = config.targets || '';
  fields.startAt.value = config.startAt || '';
  fields.endAt.value = config.endAt || '';
  fields.minInterval.value = config.minInterval;
  fields.maxInterval.value = config.maxInterval;
  fields.submitTimeout.value = config.submitTimeout;
  fields.allowWaiting.checked = Boolean(config.allowWaiting);
  fields.autoConfirm.checked = config.autoConfirm !== false;
  fields.directSubmit.checked = config.directSubmit !== false;
  fields.notify.checked = config.notify !== false;
}

function validateConfig(config) {
  if (!config.targets.split(/\r?\n/).some(line => line.trim() && !line.trim().startsWith('#'))) {
    return '请至少填写一个目标课程。';
  }
  if (config.maxInterval < config.minInterval) {
    return '最长间隔不能小于最短间隔。';
  }
  const startAt = config.startAt ? new Date(config.startAt).getTime() : null;
  const endAt = config.endAt ? new Date(config.endAt).getTime() : null;
  if (config.startAt && !Number.isFinite(startAt)) return '开始时间格式无效。';
  if (config.endAt && !Number.isFinite(endAt)) return '结束时间格式无效。';
  if (Number.isFinite(startAt) && Number.isFinite(endAt) && endAt <= startAt) {
    return '结束时间必须晚于开始时间。';
  }
  return '';
}

function updateStatus(state) {
  connected = true;
  const running = Boolean(state && state.config && state.config.enabled);
  statePill.textContent = running ? '运行中' : '已停止';
  statePill.dataset.state = running ? 'running' : 'stopped';
  statusCard.dataset.kind = state && state.statusKind ? state.statusKind : 'normal';
  statusText.textContent = state && state.status ? state.status : '已连接 MIS 页面。';
  countdown.textContent = state && state.countdown ? state.countdown : '';
  startButton.disabled = running;
  stopButton.disabled = !running;
}

function showDisconnected(message) {
  connected = false;
  statePill.textContent = '未连接';
  statePill.dataset.state = 'stopped';
  statusCard.dataset.kind = 'error';
  statusText.textContent = message;
  countdown.textContent = '';
  startButton.disabled = true;
  stopButton.disabled = true;
  saveButton.disabled = true;
}

function setBusy(busy) {
  if (busy) {
    startButton.disabled = true;
    stopButton.disabled = true;
    saveButton.disabled = true;
    statusCard.dataset.kind = 'normal';
    statusText.textContent = '正在与 MIS 页面同步配置…';
    countdown.textContent = '';
    return;
  }
  const running = statePill.dataset.state === 'running';
  startButton.disabled = !connected || running;
  stopButton.disabled = !connected || !running;
  saveButton.disabled = !connected;
}

function clampNumber(value, min, max, fallback, step = 1) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  const clamped = Math.min(max, Math.max(min, number));
  return Number((Math.round(clamped / step) * step).toFixed(6));
}
