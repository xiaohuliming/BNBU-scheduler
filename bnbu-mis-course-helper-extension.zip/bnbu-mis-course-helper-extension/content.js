(async function () {
  'use strict';

  const addDropPage = globalThis.BNBUAddDrop?.isPage(location.href) === true;
  if (location.pathname.startsWith('/mis/student/as/') && !addDropPage) return;

  const extensionStore = await chrome.storage.local.get(null);

  function GM_getValue(key, fallback) {
    return Object.prototype.hasOwnProperty.call(extensionStore, key)
      ? extensionStore[key]
      : fallback;
  }

  function GM_setValue(key, value) {
    extensionStore[key] = value;
    chrome.storage.local.set({ [key]: value });
  }

  function GM_addStyle(css) {
    const style = document.createElement('style');
    style.textContent = css;
    (document.head || document.documentElement).appendChild(style);
  }

  function GM_notification({ title, text }) {
    chrome.runtime.sendMessage({ type: 'notify', title, text }).catch(() => {});
  }

  const STORAGE_KEY = 'bnbu-course-helper-config-v1';
  const CLICK_LOCK_KEY = 'bnbu-course-helper-click-lock-v1';
  const PENDING_ACTION_KEY = 'bnbu-course-helper-pending-action-v1';
  const DIRECT_SUBMIT_EVENT = 'bnbu-course-helper-direct-submit';
  const DIRECT_POLL_EVENT = 'bnbu-course-helper-direct-poll';
  const DIRECT_RESULT_EVENT = 'bnbu-course-helper-direct-result';
  const BRIDGE_PAYLOAD_ATTRIBUTE = 'data-bch-bridge-payload';
  const MIN_INTERVAL_SECONDS = 0.5;
  const CLICK_COOLDOWN_MS = 3500;
  const PENDING_ACTION_TTL_MS = 2 * 60 * 1000;
  const DEFAULT_SUBMISSION_TIMEOUT_SECONDS = 10;
  const MAX_TIMEOUT_MS = 2147480000;

  const DEFAULT_CONFIG = {
    enabled: false,
    targets: '',
    startAt: '',
    endAt: '',
    minInterval: 0.5,
    maxInterval: 0.5,
    submitTimeout: DEFAULT_SUBMISSION_TIMEOUT_SECONDS,
    allowWaiting: false,
    autoConfirm: true,
    directSubmit: true,
    notify: true,
    collapsed: false
  };

  let config = loadConfig();
  let timer = null;
  let countdownTimer = null;
  let confirmationProbeTimer = null;
  let submissionWatchdogTimer = null;
  let directPollTimer = null;
  let directRequestId = '';
  let directTarget = null;
  let directPollUrl = '';
  let directPollAttempt = 0;
  let directPollStartedAt = 0;
  let nextRunAt = 0;
  let countdownMode = 'check';
  let panel;
  let statusNode;
  let countdownNode;
  let startButton;
  let stopButton;
  let addDropController = null;

  GM_addStyle(`
    #bnbu-course-helper {
      position: fixed;
      right: 18px;
      bottom: 18px;
      z-index: 2147483647;
      width: 356px;
      max-height: calc(100vh - 36px);
      overflow: auto;
      box-sizing: border-box;
      border: 2px solid #101820;
      border-radius: 2px;
      background: #e9eef1;
      color: #101820;
      box-shadow: 6px 6px 0 #101820;
      font: 13px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI",
        "PingFang SC", "Microsoft YaHei", sans-serif;
    }
    #bnbu-course-helper * { box-sizing: border-box; }
    #bnbu-course-helper .bch-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      min-height: 48px;
      position: sticky;
      top: 0;
      z-index: 1;
      padding: 8px 10px 8px 13px;
      border-bottom: 2px solid #101820;
      background: #101820;
      color: #f4f8fa;
      cursor: move;
      user-select: none;
    }
    #bnbu-course-helper .bch-title {
      font-size: 14px;
      font-weight: 850;
      letter-spacing: .025em;
    }
    #bnbu-course-helper .bch-collapse {
      width: 34px;
      min-width: 34px;
      height: 34px;
      border: 2px solid #f4f8fa;
      border-radius: 0;
      padding: 0;
      background: #9edfff;
      color: #101820;
      cursor: pointer;
      font: 900 18px/1 ui-monospace, "SFMono-Regular", Menlo, Consolas, monospace;
      touch-action: manipulation;
      transition: transform 100ms ease, background-color 140ms ease;
    }
    #bnbu-course-helper .bch-collapse:hover { background: #c2ecff; }
    #bnbu-course-helper .bch-collapse:active { transform: translate(2px, 2px); }
    #bnbu-course-helper .bch-collapse:focus-visible {
      outline: 3px solid #9edfff;
      outline-offset: 3px;
    }
    #bnbu-course-helper .bch-body {
      padding: 14px;
      background: #f8fbfc;
    }
    #bnbu-course-helper.bch-collapsed {
      width: 242px;
      max-height: none;
      overflow: visible;
      box-shadow: 4px 4px 0 #101820;
    }
    #bnbu-course-helper.bch-collapsed .bch-body { display: none; }
    #bnbu-course-helper label {
      display: block;
      margin: 0 0 5px;
      color: #101820;
      font-weight: 750;
    }
    #bnbu-course-helper textarea,
    #bnbu-course-helper input[type="number"],
    #bnbu-course-helper input[type="datetime-local"] {
      width: 100%;
      min-width: 0;
      min-height: 42px;
      border: 2px solid #101820;
      border-radius: 0;
      background: #fff;
      color: #101820;
      font: inherit;
      outline: none;
      transition: background-color 140ms ease, box-shadow 140ms ease;
    }
    #bnbu-course-helper textarea:hover,
    #bnbu-course-helper input[type="number"]:hover,
    #bnbu-course-helper input[type="datetime-local"]:hover {
      background: #eef9fe;
    }
    #bnbu-course-helper textarea:focus-visible,
    #bnbu-course-helper input:focus-visible {
      box-shadow: 0 0 0 3px #9edfff;
    }
    #bnbu-course-helper textarea {
      min-height: 82px;
      padding: 8px 9px;
      resize: vertical;
    }
    #bnbu-course-helper input[type="number"],
    #bnbu-course-helper input[type="datetime-local"] { padding: 7px 8px; }
    #bnbu-course-helper .bch-help {
      margin: 5px 0 12px;
      color: #53606a;
      font-size: 12px;
      line-height: 1.55;
    }
    #bnbu-course-helper .bch-row {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
      gap: 9px;
      margin-bottom: 11px;
    }
    #bnbu-course-helper .bch-checks {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 4px 10px;
      margin: 9px 0 12px;
      padding: 8px 0;
      border-top: 2px solid #101820;
      border-bottom: 2px solid #101820;
    }
    #bnbu-course-helper .bch-checks label {
      display: flex;
      min-height: 36px;
      align-items: center;
      gap: 7px;
      margin: 0;
      font-weight: 650;
      cursor: pointer;
    }
    #bnbu-course-helper .bch-checks input {
      width: 18px;
      height: 18px;
      margin: 0;
      accent-color: #36a9e1;
    }
    #bnbu-course-helper .bch-checks label:focus-within {
      outline: 3px solid #9edfff;
      outline-offset: 1px;
    }
    #bnbu-course-helper .bch-actions {
      display: grid;
      grid-template-columns: 1fr 1fr 1.15fr;
      gap: 8px;
      padding-right: 3px;
    }
    #bnbu-course-helper .bch-actions button {
      min-height: 44px;
      border: 2px solid #101820;
      border-radius: 0;
      padding: 7px 6px;
      background: #f8fbfc;
      color: #101820;
      box-shadow: 3px 3px 0 #101820;
      cursor: pointer;
      font: inherit;
      font-weight: 850;
      touch-action: manipulation;
      transition: background-color 140ms ease, box-shadow 100ms ease, transform 100ms ease;
    }
    #bnbu-course-helper .bch-actions button:hover:not(:disabled) {
      transform: translate(-1px, -1px);
      box-shadow: 4px 4px 0 #101820;
    }
    #bnbu-course-helper .bch-actions button:active:not(:disabled) {
      transform: translate(2px, 2px);
      box-shadow: 1px 1px 0 #101820;
    }
    #bnbu-course-helper .bch-actions button:focus-visible {
      outline: 3px solid #36a9e1;
      outline-offset: 3px;
    }
    #bnbu-course-helper .bch-start { background: #9edfff !important; }
    #bnbu-course-helper .bch-stop { background: #ffb9b9 !important; }
    #bnbu-course-helper .bch-check { background: #e1e8eb !important; }
    #bnbu-course-helper .bch-actions button:disabled {
      cursor: not-allowed;
      opacity: .42;
      box-shadow: 1px 1px 0 #101820;
    }
    #bnbu-course-helper .bch-status {
      margin-top: 14px;
      border: 2px solid #101820;
      border-left-width: 7px;
      border-radius: 0;
      padding: 10px;
      background: #fff;
      color: #101820;
      font-weight: 650;
      word-break: break-word;
    }
    #bnbu-course-helper .bch-status[data-kind="success"] {
      background: #b9f2d0;
      color: #123e28;
    }
    #bnbu-course-helper .bch-status[data-kind="warn"] {
      background: #ffe19a;
      color: #593c00;
    }
    #bnbu-course-helper .bch-status[data-kind="error"] {
      background: #ffc0c0;
      color: #741d1d;
    }
    #bnbu-course-helper .bch-countdown {
      margin-top: 7px;
      color: #53606a;
      font: 700 12px/1.45 ui-monospace, "SFMono-Regular", Menlo, Consolas, monospace;
      font-variant-numeric: tabular-nums;
    }
    .bch-target-highlight {
      outline: 4px solid #36a9e1 !important;
      outline-offset: 3px !important;
    }
    @media (max-width: 520px) {
      #bnbu-course-helper {
        right: 10px;
        bottom: 10px;
        left: 10px;
        width: auto;
        max-height: calc(100vh - 20px);
        overflow: auto;
      }
      #bnbu-course-helper.bch-collapsed {
        right: 10px;
        left: auto;
        width: 242px;
        overflow: visible;
      }
    }
    @media (prefers-reduced-motion: reduce) {
      #bnbu-course-helper *,
      #bnbu-course-helper *::before,
      #bnbu-course-helper *::after {
        transition: none !important;
      }
    }
  `);

  buildPanel();
  bindPanel();
  syncPanel();

  if (addDropPage) {
    addDropController = globalThis.BNBUAddDrop.create({
      getConfig: () => config,
      setStatus,
      notify,
      onStop: (message, kind) => {
        config.enabled = false;
        saveConfig();
        syncPanel();
        setStatus(message, kind);
      }
    });
  }

  window.addEventListener('beforeunload', clearTimers);
  document.addEventListener(DIRECT_RESULT_EVENT, handleDirectResult);

  if (addDropController && config.enabled) {
    addDropController.start();
  } else if (config.enabled) {
    setStatus('正在恢复监测…');
    window.setTimeout(() => scanPage(true), 350);
  } else {
    setStatus(addDropPage ? '加课模式：填写课程代码或完整名称，不写班号即不限班；不退课、不换班。' : '已停止。填写课程后点击“开始”。');
  }

  function loadConfig() {
    const saved = GM_getValue(STORAGE_KEY, {});
    const loaded = { ...DEFAULT_CONFIG, ...(saved && typeof saved === 'object' ? saved : {}) };
    // Opening the other module must not silently start a different automation.
    if (loaded.enabled && (addDropPage ? loaded.runMode !== 'add-drop' : loaded.runMode === 'add-drop')) loaded.enabled = false;
    return loaded;
  }

  function saveConfig() {
    GM_setValue(STORAGE_KEY, config);
  }

  function buildPanel() {
    panel = document.createElement('section');
    panel.id = 'bnbu-course-helper';
    panel.innerHTML = `
      <div class="bch-header">
        <span class="bch-title">抢课脚本 / 控制台</span>
        <button type="button" class="bch-collapse" title="收起或展开" aria-label="收起或展开抢课脚本控制台">−</button>
      </div>
      <div class="bch-body">
        <label for="bch-targets">${addDropPage ? '课程代码或完整名称，每行一门' : '目标课程，按行排列'}</label>
        <textarea id="bch-targets"
          placeholder="${addDropPage ? 'COMP3003&#10;Computer Vision&#10;ENG3143 | 1001' : 'COMP3003&#10;COMP3003 | 1001'}"></textarea>
        <div class="bch-help">
          ${addDropPage ? '不写班号即不限班。“完整名称 | 1001”可指定班号。同名课程不会猜选，请改填代码。' : '从上到下为优先级。“课程代码 | 班号”可精确到班级，不写班号即不限班。'}
        </div>
        <div class="bch-row">
          <div>
            <label for="bch-start-at">开始时间</label>
            <input id="bch-start-at" type="datetime-local" step="1">
          </div>
          <div>
            <label for="bch-end-at">结束时间</label>
            <input id="bch-end-at" type="datetime-local" step="1">
          </div>
        </div>
        <div class="bch-help">
          使用本机时间。开始时间留空表示立即开始，结束时间留空表示成功前持续运行。
        </div>
        <div class="bch-row">
          <div>
            <label for="bch-min">最短间隔，秒</label>
            <input id="bch-min" type="number" min="0.5" max="3600" step="0.1">
          </div>
          <div>
            <label for="bch-max">最长间隔，秒</label>
            <input id="bch-max" type="number" min="0.5" max="3600" step="0.1">
          </div>
        </div>
        <div>
          <label for="bch-submit-timeout">提交超时，秒</label>
          <input id="bch-submit-timeout" type="number" min="10" max="180" step="1">
        </div>
        <div class="bch-help">
          检查间隔默认 0.5 秒。提交超时保留 10 秒，正常响应会立即继续；请求卡住时才会在超时后刷新重试。
        </div>
        <div class="bch-checks">
          <label><input id="bch-waiting" type="checkbox">允许加入轮候</label>
          <label><input id="bch-confirm" type="checkbox">自动确认选课</label>
          <label><input id="bch-direct" type="checkbox">接口直提并确认</label>
          <label><input id="bch-notify" type="checkbox">桌面通知</label>
        </div>
        <div class="bch-actions">
          <button type="button" class="bch-start">开始</button>
          <button type="button" class="bch-stop">停止</button>
          <button type="button" class="bch-check">立即检查</button>
        </div>
        <div class="bch-status" aria-live="polite"></div>
        <div class="bch-countdown"></div>
      </div>
    `;
    document.body.appendChild(panel);

    statusNode = panel.querySelector('.bch-status');
    countdownNode = panel.querySelector('.bch-countdown');
    startButton = panel.querySelector('.bch-start');
    stopButton = panel.querySelector('.bch-stop');
  }

  function bindPanel() {
    panel.querySelector('.bch-collapse').addEventListener('click', () => {
      config.collapsed = !config.collapsed;
      saveConfig();
      syncPanel();
    });

    startButton.addEventListener('click', () => {
      readPanelConfig();
      startMonitoring();
    });

    stopButton.addEventListener('click', () => {
      stopFromControl();
    });

    panel.querySelector('.bch-check').addEventListener('click', () => {
      readPanelConfig();
      if (addDropController) config.enabled = false;
      saveConfig();
      clearTimers();
      if (addDropController) {
        syncPanel();
        addDropController.start({ preview: true });
      } else scanPage(false, true);
    });
  }

  function applyExternalConfig(nextConfig) {
    const enabled = config.enabled;
    config = { ...DEFAULT_CONFIG, ...config, ...(nextConfig || {}), enabled };
    saveConfig();
    syncPanel();
  }

  function startMonitoring(nextConfig) {
    if (nextConfig) applyExternalConfig(nextConfig);
    if (!parseTargets(config.targets).length) {
      setStatus(addDropPage ? '请至少填写一个课程代码或完整课程名称。' : '请至少填写一个课程代码。', 'error');
      return { ok: false, message: statusNode.textContent };
    }
    const scheduleError = validateScheduleConfig();
    if (scheduleError) {
      setStatus(scheduleError, 'error');
      return { ok: false, message: scheduleError };
    }
    clearPendingAction();
    config.runMode = addDropPage ? 'add-drop' : 'selection';
    config.enabled = true;
    saveConfig();
    syncPanel();
    clearTimers();
    if (addDropController) return addDropController.start();
    scanPage(false);
    return { ok: true, message: statusNode.textContent };
  }

  function stopFromControl() {
    config.enabled = false;
    saveConfig();
    clearPendingAction();
    clearTimers();
    syncPanel();
    setStatus(addDropPage ? '监测已停止。若已经发出加课请求，请到 MIS 核对最终结果。' : '监测已停止。');
    return { ok: true, message: statusNode.textContent };
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || !message.type) return;

    if (message.type === 'get-state') {
      sendResponse({
        ok: true,
        config,
        mode: addDropPage ? 'add-drop' : 'selection',
        status: statusNode.textContent,
        statusKind: statusNode.dataset.kind || 'normal',
        countdown: countdownNode.textContent,
        url: location.href
      });
      return;
    }

    if (message.type === 'apply-config') {
      if (addDropController) clearTimers();
      applyExternalConfig(message.config);
      if (addDropController && config.enabled) addDropController.start();
      setStatus(config.enabled ? '配置已更新，监测继续运行。' : '配置已保存。', 'success');
      sendResponse({ ok: true, status: statusNode.textContent, config });
      return;
    }

    if (message.type === 'start-monitoring') {
      sendResponse(startMonitoring(message.config));
      return;
    }

    if (message.type === 'stop-monitoring') {
      sendResponse(stopFromControl());
    }
    if (message.type === 'ack-adddrop-result' && addDropController) {
      if (config.enabled) { sendResponse({ ok: false, message: '请先停止监测再核对结果。' }); return; }
      addDropController.acknowledgeStopped().then(() => {
        setStatus('已解除待确认状态。确认目标课程后可重新开始。');
        sendResponse({ ok: true });
      }).catch(() => sendResponse({ ok: false, message: '无法清除待确认状态，请重试。' }));
      return true;
    }
  });

  function readPanelConfig() {
    config.targets = panel.querySelector('#bch-targets').value;
    config.startAt = panel.querySelector('#bch-start-at').value;
    config.endAt = panel.querySelector('#bch-end-at').value;
    config.minInterval = clampNumber(
      panel.querySelector('#bch-min').value,
      MIN_INTERVAL_SECONDS,
      3600,
      DEFAULT_CONFIG.minInterval,
      0.1
    );
    config.maxInterval = clampNumber(
      panel.querySelector('#bch-max').value,
      config.minInterval,
      3600,
      Math.max(DEFAULT_CONFIG.maxInterval, config.minInterval),
      0.1
    );
    config.submitTimeout = clampNumber(
      panel.querySelector('#bch-submit-timeout').value,
      10,
      180,
      DEFAULT_CONFIG.submitTimeout
    );
    config.allowWaiting = panel.querySelector('#bch-waiting').checked;
    config.autoConfirm = panel.querySelector('#bch-confirm').checked;
    config.directSubmit = panel.querySelector('#bch-direct').checked;
    config.notify = panel.querySelector('#bch-notify').checked;
  }

  function syncPanel() {
    panel.classList.toggle('bch-collapsed', config.collapsed);
    panel.querySelector('.bch-collapse').textContent = config.collapsed ? '+' : '−';
    panel.querySelector('#bch-targets').value = config.targets;
    panel.querySelector('#bch-start-at').value = config.startAt;
    panel.querySelector('#bch-end-at').value = config.endAt;
    panel.querySelector('#bch-min').value = config.minInterval;
    panel.querySelector('#bch-max').value = config.maxInterval;
    panel.querySelector('#bch-submit-timeout').value = config.submitTimeout;
    panel.querySelector('#bch-waiting').checked = config.allowWaiting;
    panel.querySelector('#bch-confirm').checked = config.autoConfirm;
    panel.querySelector('#bch-direct').checked = config.directSubmit !== false;
    panel.querySelector('#bch-notify').checked = config.notify;
    startButton.disabled = config.enabled;
    stopButton.disabled = !config.enabled;
  }

  function parseTargets(raw) {
    return String(raw || '')
      .split(/\r?\n/)
      .map(line => line.trim())
      .filter(line => line && !line.startsWith('#'))
      .map(line => {
        const parts = line.split(/\s*[|,，]\s*/);
        return {
          raw: line,
          course: (parts[0] || '').trim(),
          section: (parts[1] || '').trim()
        };
      })
      .filter(target => target.course);
  }

  function validateScheduleConfig() {
    const startAt = parseScheduleTime(config.startAt);
    const endAt = parseScheduleTime(config.endAt);

    if (config.startAt && !Number.isFinite(startAt)) {
      return '开始时间格式无效。';
    }
    if (config.endAt && !Number.isFinite(endAt)) {
      return '结束时间格式无效。';
    }
    if (Number.isFinite(startAt) && Number.isFinite(endAt) && endAt <= startAt) {
      return '结束时间必须晚于开始时间。';
    }
    return '';
  }

  function parseScheduleTime(value) {
    if (!value) return null;
    const timestamp = new Date(value).getTime();
    return Number.isFinite(timestamp) ? timestamp : NaN;
  }

  function getScheduleState(now = Date.now()) {
    const startAt = parseScheduleTime(config.startAt);
    const endAt = parseScheduleTime(config.endAt);

    if (Number.isFinite(endAt) && now >= endAt) {
      return { kind: 'ended', startAt, endAt };
    }
    if (Number.isFinite(startAt) && now < startAt) {
      return { kind: 'waiting', startAt, endAt };
    }
    return { kind: 'active', startAt, endAt };
  }

  function formatLocalTime(timestamp) {
    return new Date(timestamp).toLocaleString('zh-CN', { hour12: false });
  }

  function scanPage(fromAutomaticRun, previewOnly = false) {
    clearTimers();

    const targets = parseTargets(config.targets);
    if (!targets.length) {
      setStatus('没有有效的目标课程。', 'error');
      stopMonitoring();
      return;
    }

    if (isLoginPage()) {
      setStatus('登录已失效，请重新登录 MIS。监测已停止。', 'error');
      stopMonitoring();
      notify('抢课脚本', '登录已失效，请重新登录。');
      return;
    }

    if (!previewOnly) {
      const scheduleState = getScheduleState();
      if (scheduleState.kind === 'waiting') {
        scheduleStart(scheduleState.startAt);
        return;
      }
      if (scheduleState.kind === 'ended') {
        setStatus(`抢课时间已于 ${formatLocalTime(scheduleState.endAt)} 结束。`, 'warn');
        stopMonitoring();
        notify('抢课脚本', '抢课时间已结束，监测已停止。');
        return;
      }

      if (config.autoConfirm && confirmPendingSelection()) {
        return;
      }
    }

    removeHighlights();

    for (const target of targets) {
      const container = findTargetContainer(target);
      if (!container) continue;

      container.classList.add('bch-target-highlight');
      const state = getContainerState(container);

      if (state === 'selected') {
        setStatus(`已确认选中：${target.raw}`, 'success');
        clearPendingAction();
        stopMonitoring();
        notify('选课成功', `${target.raw} 已显示为 Selected。`);
        return;
      }

      if (state === 'waiting') {
        setStatus(`已加入轮候：${target.raw}`, 'success');
        clearPendingAction();
        stopMonitoring();
        notify('已加入轮候', `${target.raw} 已显示为 Waiting。`);
        return;
      }

      const action = findAction(container, config.allowWaiting);
      if (action) {
        if (previewOnly) {
          setStatus(`检查完成：${target.raw} 当前存在可执行操作，启动后会自动提交。`, 'success');
          return;
        }
        if (clickAction(action, target)) return;
      }

      setStatus(
        `已找到 ${target.raw}，当前没有可执行的选课${config.allowWaiting ? '或轮候' : ''}按钮。`,
        'warn'
      );
    }

    if (!document.querySelector('.bch-target-highlight')) {
      if (isElectiveHomePage()) {
        const courseListEntry = findCourseListEntry();
        if (courseListEntry) {
          if (previewOnly) {
            setStatus('检查完成：已找到课程列表入口，启动后会自动进入并检查目标课程。');
            return;
          }
          enterCourseList(courseListEntry);
          return;
        }
        setStatus('当前没有可进入的“Select Course / Item”课程列表。', 'warn');
      } else {
        setStatus(
          isCourseListPage()
            ? '当前列表未找到目标课程。'
            : '当前页面不是 MIS 选课首页或课程列表页。',
          'warn'
        );
      }
    }

    if (previewOnly) return;

    if (config.enabled) {
      if (isCourseListPage() || isElectiveHomePage()) {
        scheduleReload();
      } else if (fromAutomaticRun) {
        const pending = getPendingAction();
        if (pending && isStudentSelectionArea()) {
          setStatus(
            `正在恢复 ${pending.target} 的第 ${pending.attempt || 1} 次提交，等待页面恢复。`,
            'warn'
          );
          scheduleReload(5);
        } else {
          stopMonitoring();
          setStatus('当前不是 MIS 选课首页或课程列表页，已停止自动刷新。', 'warn');
        }
      }
    }
  }

  function findCourseListEntry() {
    const elements = Array.from(document.querySelectorAll(
      'a[href], button, input[type="button"], input[type="submit"], input[type="image"], [role="button"]'
    ));

    return elements.find(element => {
      if (element.disabled) return false;
      if (element.getAttribute('aria-disabled') === 'true') return false;
      if (/\bdisabled\b/i.test(element.className || '')) return false;

      const visibleLabel = normalize([
        element.innerText,
        element.value,
        element.getAttribute('aria-label'),
        element.getAttribute('alt'),
        ...Array.from(element.querySelectorAll('img')).map(image =>
          image.getAttribute('alt') || image.getAttribute('title') || ''
        )
      ].filter(Boolean).join(' '));

      return visibleLabel === 'SELECT COURSE / ITEM' ||
        visibleLabel === 'SELECT COURSE/ITEM' ||
        visibleLabel === '选择课程 / 项目' ||
        visibleLabel === '选择课程/项目';
    }) || null;
  }

  function enterCourseList(entry) {
    setStatus('正在进入“Select Course / Item”课程列表…', 'success');
    entry.scrollIntoView({ behavior: 'smooth', block: 'center' });

    window.setTimeout(() => {
      try {
        entry.click();
      } catch (error) {
        setStatus(`无法进入课程列表：${error.message}`, 'error');
        if (config.enabled) scheduleReload(4);
      }
    }, 200);

    window.setTimeout(() => {
      if (config.enabled && isElectiveHomePage() && document.visibilityState !== 'hidden') {
        setStatus('课程列表没有打开，将重试。', 'warn');
        scheduleReload(4);
      }
    }, 2500);
  }

  function findTargetContainer(target, root = document) {
    const rows = Array.from(root.querySelectorAll('tr'));
    const matchingRows = rows.filter(row => matchesTarget(getElementText(row), target));
    if (matchingRows.length) {
      return matchingRows.sort((a, b) =>
        getElementText(a).length - getElementText(b).length
      )[0];
    }

    const candidates = Array.from(root.querySelectorAll(
      '[class*="course"], [class*="item"], [class*="elective"], li, form'
    )).filter(element => matchesTarget(getElementText(element), target));

    if (candidates.length) {
      return candidates.sort((a, b) =>
        getElementText(a).length - getElementText(b).length
      )[0];
    }

    return null;
  }

  function matchesTarget(text, target) {
    const normalizedText = normalize(text);
    const courseMatched = containsToken(normalizedText, normalize(target.course));
    const sectionMatched = !target.section ||
      containsToken(normalizedText, normalize(target.section));
    return courseMatched && sectionMatched;
  }

  function getContainerState(container) {
    const text = normalize(getElementText(container));
    if (/(^|\s)(SELECTED|ENROLLED)(\s|$)|已选|选课成功/.test(text)) {
      return 'selected';
    }
    if (/(^|\s)(WAITING|WAITLISTED)(\s|$)|轮候中|已轮候|候补中/.test(text)) {
      return 'waiting';
    }
    return 'available-or-unknown';
  }

  function getElementText(element) {
    return String((element && (element.innerText || element.textContent)) || '');
  }

  function findAction(container, allowWaiting) {
    const elements = Array.from(container.querySelectorAll(
      'a[href], button, input[type="button"], input[type="submit"], input[type="image"], [role="button"]'
    ));

    const usable = elements.filter(element => {
      if (element.disabled) return false;
      if (element.getAttribute('aria-disabled') === 'true') return false;
      if (/\bdisabled\b/i.test(element.className || '')) return false;

      const label = normalize(getActionLabel(element));
      const excluded = /DROP|WITHDRAW|EXIT|REPLACE|VIEW|DETAIL|CANCEL|REMOVE|退选|退出|替换|查看|取消|删除|SELECTED|已选/;
      if (excluded.test(label)) return false;

      const selectAction = /SELECT(?!ED)|ENROL|REGISTER|ADD COURSE|CHOOSE|选课|选择课程|加入课程|抢课/.test(label);
      const waitingAction = /WAITING|WAITLIST|JOIN WAIT|轮候|候补|排队/.test(label);
      return selectAction || (allowWaiting && waitingAction);
    });

    usable.sort((a, b) => actionPriority(a, allowWaiting) - actionPriority(b, allowWaiting));
    return usable[0] || null;
  }

  function getActionLabel(element) {
    const imageAlt = Array.from(element.querySelectorAll('img'))
      .map(image => image.getAttribute('alt') || image.getAttribute('title') || '')
      .join(' ');
    return [
      element.innerText,
      element.value,
      element.getAttribute('title'),
      element.getAttribute('aria-label'),
      element.getAttribute('alt'),
      element.getAttribute('src'),
      element.getAttribute('href'),
      element.getAttribute('onclick'),
      imageAlt
    ].filter(Boolean).join(' ');
  }

  function actionPriority(element, allowWaiting) {
    const label = normalize(getActionLabel(element));
    if (/SELECT(?!ED)|ENROL|REGISTER|选课|选择课程/.test(label)) return 1;
    if (/ADD COURSE|CHOOSE|加入课程|抢课/.test(label)) return 2;
    if (allowWaiting && /WAIT|轮候|候补|排队/.test(label)) return 3;
    return 99;
  }

  function confirmPendingSelection() {
    const pending = getPendingAction();
    if (!pending) return false;

    const confirmationAction = findConfirmationAction();
    if (!confirmationAction) return false;

    clearSubmissionTimers();
    setStatus(`正在自动确认选课：${pending.target}`, 'success');
    confirmationAction.scrollIntoView({ behavior: 'smooth', block: 'center' });
    window.setTimeout(() => {
      try {
        clickWithNativeConfirmation(confirmationAction);
      } catch (error) {
        setStatus(`自动确认失败：${error.message}`, 'error');
        if (config.enabled) scheduleReload(3);
      }
    }, 150);
    scheduleSubmissionWatchdog(pending.target);
    return true;
  }

  function findConfirmationAction() {
    const elements = Array.from(document.querySelectorAll(
      'a[href], button, input[type="button"], input[type="submit"], input[type="image"], [role="button"]'
    ));

    return elements.find(element => {
      if (element.disabled) return false;
      if (element.getAttribute('aria-disabled') === 'true') return false;
      if (/\bdisabled\b/i.test(element.className || '')) return false;

      const label = normalize(getVisibleActionLabel(element));
      if (/^(CONFIRM|YES|确认|确定|确认选课|确认选择|提交选课)$/.test(label)) {
        return true;
      }

      if (!/^(OK|SUBMIT|提交)$/.test(label)) return false;
      const form = typeof element.closest === 'function' ? element.closest('form') : null;
      const contextText = normalize([
        form && form.innerText,
        element.getAttribute('href'),
        element.getAttribute('onclick')
      ].filter(Boolean).join(' '));
      return /COURSE|ELECTIVE|SELECT|ENROL|选课|课程/.test(contextText);
    }) || null;
  }

  function getVisibleActionLabel(element) {
    const imageAlt = Array.from(element.querySelectorAll('img'))
      .map(image => image.getAttribute('alt') || image.getAttribute('title') || '')
      .join(' ');
    return [
      element.innerText,
      element.value,
      element.getAttribute('title'),
      element.getAttribute('aria-label'),
      element.getAttribute('alt'),
      imageAlt
    ].filter(Boolean).join(' ');
  }

  function getPendingAction() {
    const pending = GM_getValue(PENDING_ACTION_KEY, null);
    if (!pending || !pending.target || !pending.time) return null;
    if (Date.now() - Number(pending.time) > PENDING_ACTION_TTL_MS) {
      clearPendingAction();
      return null;
    }
    return pending;
  }

  function clearPendingAction() {
    GM_setValue(PENDING_ACTION_KEY, null);
  }

  function clickWithNativeConfirmation(action) {
    if (config.autoConfirm) {
      document.dispatchEvent(new CustomEvent('bnbu-course-helper-arm-confirm'));
    }
    action.click();
  }

  function scheduleConfirmationProbe() {
    if (confirmationProbeTimer) {
      window.clearTimeout(confirmationProbeTimer);
    }
    confirmationProbeTimer = window.setTimeout(() => {
      confirmationProbeTimer = null;
      if (config.enabled && config.autoConfirm) {
        confirmPendingSelection();
      }
    }, 1250);
  }

  function scheduleSubmissionWatchdog(target) {
    if (submissionWatchdogTimer) {
      window.clearTimeout(submissionWatchdogTimer);
    }
    const timeoutSeconds = clampNumber(
      config.submitTimeout,
      10,
      180,
      DEFAULT_SUBMISSION_TIMEOUT_SECONDS
    );
    submissionWatchdogTimer = window.setTimeout(() => {
      submissionWatchdogTimer = null;
      if (!config.enabled) return;
      setStatus(
        `提交 ${target} 后 ${timeoutSeconds} 秒仍未收到服务器结果，正在安全刷新并重试。`,
        'warn'
      );
      scheduleReload(2);
    }, timeoutSeconds * 1000);
  }

  function clearSubmissionTimers() {
    if (confirmationProbeTimer) {
      window.clearTimeout(confirmationProbeTimer);
    }
    if (submissionWatchdogTimer) {
      window.clearTimeout(submissionWatchdogTimer);
    }
    if (directPollTimer) {
      window.clearTimeout(directPollTimer);
    }
    confirmationProbeTimer = null;
    submissionWatchdogTimer = null;
    directPollTimer = null;
    directRequestId = '';
    directTarget = null;
    directPollUrl = '';
    directPollAttempt = 0;
    directPollStartedAt = 0;
  }

  function createDirectRequestId() {
    return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  }

  function beginDirectSubmission(action, target) {
    clearSubmissionTimers();
    directRequestId = createDirectRequestId();
    directTarget = target;
    directPollUrl = location.href;
    directPollAttempt = 0;
    directPollStartedAt = Date.now();

    const timeoutSeconds = clampNumber(
      config.submitTimeout,
      10,
      180,
      DEFAULT_SUBMISSION_TIMEOUT_SECONDS
    );
    action.setAttribute('data-bch-direct-request-id', directRequestId);
    action.setAttribute('data-bch-direct-timeout-ms', String(timeoutSeconds * 1000));
    setStatus(`接口 POST 已发出，正在快速确认：${target.raw}`, 'success');
    action.dispatchEvent(new CustomEvent(DIRECT_SUBMIT_EVENT, {
      bubbles: true,
      cancelable: false
    }));
    action.removeAttribute('data-bch-direct-request-id');
    action.removeAttribute('data-bch-direct-timeout-ms');
    scheduleSubmissionWatchdog(target.raw);
    scheduleDirectPoll(MIN_INTERVAL_SECONDS * 1000);
  }

  function beginRecoveredDirectPolling(target, startedAt = Date.now()) {
    clearSubmissionTimers();
    directRequestId = createDirectRequestId();
    directTarget = target;
    directPollUrl = location.href;
    directPollAttempt = 0;
    directPollStartedAt = Number(startedAt) || Date.now();
    scheduleSubmissionWatchdog(target.raw);
    scheduleDirectPoll(100);
  }

  function handleDirectResult(event) {
    let result;
    try {
      const carrier = event.target;
      const payload = carrier && typeof carrier.getAttribute === 'function' &&
        carrier.getAttribute(BRIDGE_PAYLOAD_ATTRIBUTE) === 'result'
        ? carrier.textContent
        : event.detail;
      result = JSON.parse(payload || '{}');
    } catch (_) {
      return;
    }
    if (!config.enabled || !directRequestId || result.requestId !== directRequestId) return;

    if (result.responseUrl && isSafeStudentSelectionUrl(result.responseUrl)) {
      directPollUrl = result.responseUrl;
    }

    const responseState = inspectDirectResponse(result, directTarget);
    if (responseState.kind === 'login') {
      setStatus('接口返回登录失效，请重新登录 MIS。监测已停止。', 'error');
      stopMonitoring();
      notify('抢课脚本', '登录已失效，请重新登录。');
      return;
    }
    if (responseState.kind === 'selected') {
      setStatus(`接口已确认选中：${directTarget.raw}`, 'success');
      clearPendingAction();
      stopMonitoring();
      notify('选课成功', `${directTarget.raw} 已由接口确认为 Selected。`);
      return;
    }
    if (responseState.kind === 'waiting') {
      setStatus(`接口已确认加入轮候：${directTarget.raw}`, 'success');
      clearPendingAction();
      stopMonitoring();
      notify('已加入轮候', `${directTarget.raw} 已由接口确认为 Waiting。`);
      return;
    }

    if (responseState.kind === 'rejected') {
      setStatus(
        `接口未接受 ${directTarget.raw}：${responseState.message}。将继续监测名额。`,
        'warn'
      );
      scheduleReload();
      return;
    }

    if (result.status === 401 || result.status === 403) {
      setStatus(`接口返回 HTTP ${result.status}，可能需要重新登录。`, 'error');
      scheduleDirectPoll(1500);
      return;
    }

    const busy = result.status === 429 || result.status >= 500 || result.timedOut;
    const detail = result.mode === 'poll' && result.status === 200
      ? `第 ${directPollAttempt} 次确认尚未显示最终状态`
      : result.timedOut
        ? '提交请求等待超时，但服务器仍可能已收到'
        : result.status
          ? `接口返回 HTTP ${result.status}`
          : result.error || '尚未取得明确结果';
    setStatus(
      `${detail}，将继续快速确认 ${directTarget.raw}。`,
      busy ? 'warn' : 'success'
    );
    scheduleDirectPoll(busy ? Math.max(1000, getDirectPollIntervalMs()) : undefined);
  }

  function inspectDirectResponse(result, target) {
    const responseUrl = String(result.responseUrl || '');
    if (/\/(login|logout)(?:\.|\/)|login\.jsp/i.test(responseUrl)) {
      return { kind: 'login' };
    }
    if (!result.text) return { kind: 'unknown' };

    let parsed;
    try {
      parsed = new DOMParser().parseFromString(result.text, 'text/html');
    } catch (_) {
      parsed = null;
    }
    if (parsed && parsed.querySelector('input[type="password"]')) {
      return { kind: 'login' };
    }

    const container = parsed && target ? findTargetContainer(target, parsed) : null;
    if (container) {
      const state = getContainerState(container);
      if (state === 'selected' || state === 'waiting') return { kind: state };
    }

    const text = normalize(parsed && parsed.body ? parsed.body.textContent : result.text);
    if (/SUCCESSFULLY SELECTED|COURSE SELECTION SUCCESS|SELECT COURSE SUCCESS|选课成功|成功选择课程/.test(text)) {
      return { kind: 'selected' };
    }
    if (/SUCCESSFULLY WAITLISTED|JOINED (THE )?WAITING|WAITLIST SUCCESS|轮候成功|候补成功/.test(text)) {
      return { kind: 'waiting' };
    }

    const rejectionPatterns = [
      [/TIME CONFLICT|SCHEDULE CONFLICT|时间冲突|课程冲突/, '课程时间冲突'],
      [/NO (SEAT|QUOTA)|QUOTA (IS )?FULL|COURSE (IS )?FULL|NO VACANCY|名额已满|没有名额|无剩余名额/, '课程当前没有名额'],
      [/NOT (IN )?SELECTION TIME|OUTSIDE.*SELECTION|未到选课时间|不在选课时间/, '当前不在选课时间'],
      [/ALREADY (SELECTED|ENROLLED)|已经选过|重复选课/, '课程已经在选课记录中']
    ];
    for (const [pattern, message] of rejectionPatterns) {
      if (pattern.test(text)) return { kind: 'rejected', message };
    }
    return { kind: 'unknown' };
  }

  function isSafeStudentSelectionUrl(value) {
    try {
      const url = new URL(value, location.href);
      return url.origin === location.origin &&
        url.pathname.toLowerCase().startsWith('/mis/student/es/');
    } catch (_) {
      return false;
    }
  }

  function getDirectPollIntervalMs() {
    const seconds = clampNumber(
      config.minInterval,
      MIN_INTERVAL_SECONDS,
      5,
      MIN_INTERVAL_SECONDS,
      0.1
    );
    return seconds * 1000;
  }

  function scheduleDirectPoll(forcedDelayMs) {
    if (!config.enabled || !directRequestId || !directTarget) return;
    if (directPollTimer) window.clearTimeout(directPollTimer);

    const timeoutMs = clampNumber(
      config.submitTimeout,
      10,
      180,
      DEFAULT_SUBMISSION_TIMEOUT_SECONDS
    ) * 1000;
    if (Date.now() - directPollStartedAt >= timeoutMs) return;

    const delay = Number.isFinite(forcedDelayMs)
      ? Math.max(100, forcedDelayMs)
      : getDirectPollIntervalMs();
    directPollTimer = window.setTimeout(() => {
      directPollTimer = null;
      directPollAttempt += 1;
      dispatchBridgeCommand(DIRECT_POLL_EVENT, {
        requestId: directRequestId,
        url: directPollUrl || location.href,
        timeoutMs: Math.min(10000, timeoutMs)
      });
    }, delay);
  }

  function dispatchBridgeCommand(eventName, payload) {
    const carrier = document.createElement('script');
    carrier.type = 'application/json';
    carrier.setAttribute(BRIDGE_PAYLOAD_ATTRIBUTE, 'command');
    carrier.textContent = JSON.stringify(payload);
    (document.documentElement || document.body).appendChild(carrier);
    carrier.dispatchEvent(new CustomEvent(eventName, { bubbles: true }));
    carrier.remove();
  }

  function clickAction(action, target) {
    const now = Date.now();
    const lock = GM_getValue(CLICK_LOCK_KEY, null);
    if (lock && lock.target === target.raw &&
        now - Number(lock.time || 0) < CLICK_COOLDOWN_MS) {
      setStatus(`已提交 ${target.raw}，正在接口确认服务器状态。`, 'warn');
      if (config.directSubmit !== false) {
        beginRecoveredDirectPolling(target, lock.time);
      } else {
        scheduleReload(2);
      }
      return true;
    }

    const previousPending = getPendingAction();
    const attempt = previousPending && previousPending.target === target.raw
      ? Math.max(1, Number(previousPending.attempt || 0) + 1)
      : 1;

    GM_setValue(CLICK_LOCK_KEY, { target: target.raw, time: now });
    GM_setValue(PENDING_ACTION_KEY, {
      target: target.raw,
      time: now,
      attempt,
      action: normalize(getVisibleActionLabel(action))
    });
    setStatus(
      config.directSubmit !== false
        ? `发现可用名额，正在第 ${attempt} 次接口直提：${target.raw}`
        : `发现可用名额，正在第 ${attempt} 次页面提交：${target.raw}`,
      'success'
    );
    notify('发现可用名额', `正在第 ${attempt} 次提交 ${target.raw}`);

    if (config.directSubmit !== false) {
      beginDirectSubmission(action, target);
      return true;
    }

    clearSubmissionTimers();
    action.scrollIntoView({ behavior: 'smooth', block: 'center' });
    window.setTimeout(() => {
      try {
        clickWithNativeConfirmation(action);
      } catch (error) {
        setStatus(`点击失败：${error.message}`, 'error');
        if (config.enabled) scheduleReload();
      }
    }, 250);
    scheduleConfirmationProbe();
    scheduleSubmissionWatchdog(target.raw);
    return true;
  }

  function isCourseListPage() {
    const path = location.pathname.toLowerCase();
    return /\/(eledetail|replacelist|replacedetail)\.do$/.test(path);
  }

  function isElectiveHomePage() {
    const path = location.pathname.toLowerCase();
    return /\/(index|elective)\.do$/.test(path);
  }

  function isStudentSelectionArea() {
    return location.pathname.toLowerCase().startsWith('/mis/student/es/');
  }

  function isLoginPage() {
    return Boolean(
      document.querySelector('input[type="password"]') ||
      /\/(login|logout)\./i.test(location.pathname)
    );
  }

  function scheduleStart(startAt) {
    if (!config.enabled) return;
    clearTimers();

    const delay = Math.max(0, Math.min(startAt - Date.now(), MAX_TIMEOUT_MS));
    nextRunAt = startAt;
    countdownMode = 'start';
    setStatus(`已排程，等待 ${formatLocalTime(startAt)} 开始抢课。`);
    updateCountdown();
    countdownTimer = window.setInterval(updateCountdown, 250);
    timer = window.setTimeout(() => location.reload(), delay);
  }

  function scheduleReload(forcedSeconds) {
    if (!config.enabled) return;
    clearTimers();

    const minSeconds = clampNumber(
      config.minInterval,
      MIN_INTERVAL_SECONDS,
      3600,
      DEFAULT_CONFIG.minInterval,
      0.1
    );
    const maxSeconds = clampNumber(
      config.maxInterval,
      minSeconds,
      3600,
      Math.max(DEFAULT_CONFIG.maxInterval, minSeconds),
      0.1
    );
    const seconds = forcedSeconds ?? randomIntervalSeconds(minSeconds, maxSeconds);
    const scheduleState = getScheduleState();
    if (scheduleState.kind === 'ended') {
      setStatus(`抢课时间已于 ${formatLocalTime(scheduleState.endAt)} 结束。`, 'warn');
      stopMonitoring();
      return;
    }

    let delay = seconds * 1000;
    if (Number.isFinite(scheduleState.endAt)) {
      delay = Math.min(delay, Math.max(0, scheduleState.endAt - Date.now()));
    }

    nextRunAt = Date.now() + delay;
    countdownMode = 'check';
    setStatus(`${statusNode.textContent} 将自动刷新。`, statusNode.dataset.kind);
    updateCountdown();
    countdownTimer = window.setInterval(updateCountdown, 250);
    timer = window.setTimeout(() => location.reload(), Math.min(delay, MAX_TIMEOUT_MS));
  }

  function updateCountdown() {
    if (!nextRunAt) {
      countdownNode.textContent = '';
      return;
    }
    const remainingMs = Math.max(0, nextRunAt - Date.now());
    const remaining = remainingMs < 10000
      ? (Math.ceil(remainingMs / 100) / 10).toFixed(1)
      : String(Math.ceil(remainingMs / 1000));
    countdownNode.textContent = countdownMode === 'start'
      ? `距离开始：${remaining} 秒`
      : `下次检查：${remaining} 秒后`;
  }

  function stopMonitoring() {
    config.enabled = false;
    saveConfig();
    clearPendingAction();
    clearTimers();
    syncPanel();
  }

  function clearTimers() {
    if (addDropController) addDropController.stop();
    if (timer) window.clearTimeout(timer);
    if (countdownTimer) window.clearInterval(countdownTimer);
    clearSubmissionTimers();
    timer = null;
    countdownTimer = null;
    nextRunAt = 0;
    countdownMode = 'check';
    if (countdownNode) countdownNode.textContent = '';
  }

  function removeHighlights() {
    document.querySelectorAll('.bch-target-highlight')
      .forEach(element => element.classList.remove('bch-target-highlight'));
  }

  function setStatus(message, kind = 'normal') {
    statusNode.textContent = message;
    statusNode.dataset.kind = kind;
  }

  function notify(title, text) {
    if (!config.notify) return;
    try {
      GM_notification({ title, text, timeout: 8000 });
    } catch (_) {
      // Notifications are optional and must not interrupt course monitoring.
    }
  }

  function normalize(value) {
    return String(value || '')
      .replace(/\s+/g, ' ')
      .trim()
      .toUpperCase();
  }

  function containsToken(text, token) {
    if (!token) return true;
    const escaped = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp(`(^|[^A-Z0-9])${escaped}([^A-Z0-9]|$)`, 'i').test(text);
  }

  function clampNumber(value, min, max, fallback, step = 1) {
    const number = Number(value);
    if (!Number.isFinite(number)) return fallback;
    const clamped = Math.min(max, Math.max(min, number));
    return Number((Math.round(clamped / step) * step).toFixed(6));
  }

  function randomIntervalSeconds(min, max) {
    const lower = Math.min(min, max);
    const upper = Math.max(min, max);
    return Math.round((lower + Math.random() * (upper - lower)) * 10) / 10;
  }
})();
