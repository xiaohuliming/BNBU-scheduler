(() => {
  'use strict';

  const ARM_EVENT = 'bnbu-course-helper-arm-confirm';
  const DIRECT_SUBMIT_EVENT = 'bnbu-course-helper-direct-submit';
  const DIRECT_POLL_EVENT = 'bnbu-course-helper-direct-poll';
  const DIRECT_RESULT_EVENT = 'bnbu-course-helper-direct-result';
  const REQUEST_ID_ATTRIBUTE = 'data-bch-direct-request-id';
  const REQUEST_TIMEOUT_ATTRIBUTE = 'data-bch-direct-timeout-ms';
  const BRIDGE_PAYLOAD_ATTRIBUTE = 'data-bch-bridge-payload';
  const GUARD_MS = 15 * 1000;
  const MAX_RESPONSE_CHARS = 750000;

  let restoreActiveConfirm = null;
  let activeDirectRequest = null;

  function armConfirmation() {
    if (restoreActiveConfirm) restoreActiveConfirm();

    const originalConfirm = window.confirm;
    let restoreTimer = null;

    const restore = () => {
      if (restoreTimer) window.clearTimeout(restoreTimer);
      if (window.confirm === autoConfirmOnce) {
        window.confirm = originalConfirm;
      }
      restoreActiveConfirm = null;
    };

    function autoConfirmOnce() {
      restore();
      return true;
    }

    window.confirm = autoConfirmOnce;
    restoreActiveConfirm = restore;
    restoreTimer = window.setTimeout(restore, GUARD_MS);
  }

  function emitResult(result) {
    const payload = JSON.stringify(result);
    if (typeof document.createElement !== 'function') {
      document.dispatchEvent(new CustomEvent(DIRECT_RESULT_EVENT, { detail: payload }));
      return;
    }

    const carrier = document.createElement('script');
    carrier.type = 'application/json';
    carrier.setAttribute(BRIDGE_PAYLOAD_ATTRIBUTE, 'result');
    carrier.textContent = payload;
    (document.documentElement || document).appendChild(carrier);
    carrier.dispatchEvent(new CustomEvent(DIRECT_RESULT_EVENT, { bubbles: true }));
    carrier.remove();
  }

  function sameOriginUrl(value) {
    try {
      const url = new URL(value || location.href, location.href);
      return url.origin === location.origin ? url : null;
    } catch (_) {
      return null;
    }
  }

  function consumeDirectRequest() {
    const request = activeDirectRequest;
    if (!request || request.consumed) return null;
    request.consumed = true;
    if (request.guardTimer) window.clearTimeout(request.guardTimer);
    activeDirectRequest = null;
    return request;
  }

  function buildFormRequest(form, submitter) {
    const url = sameOriginUrl(form.action || location.href);
    if (!url) throw new Error('MIS 表单目标不是同源地址。');

    let formData;
    try {
      formData = new FormData(form, submitter || undefined);
    } catch (_) {
      formData = new FormData(form);
      if (submitter && submitter.name) {
        const type = String(submitter.type || '').toLowerCase();
        if (type === 'image') {
          formData.append(`${submitter.name}.x`, '1');
          formData.append(`${submitter.name}.y`, '1');
        } else {
          formData.append(submitter.name, submitter.value || '');
        }
      }
    }

    const method = String(form.method || 'GET').toUpperCase();
    const headers = {
      Accept: 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8'
    };
    let body;

    if (method === 'GET' || method === 'HEAD') {
      for (const [name, value] of formData.entries()) {
        url.searchParams.append(name, typeof value === 'string' ? value : value.name);
      }
    } else if (/multipart\/form-data/i.test(form.enctype || '')) {
      body = formData;
    } else {
      const encoded = new URLSearchParams();
      for (const [name, value] of formData.entries()) {
        encoded.append(name, typeof value === 'string' ? value : value.name);
      }
      body = encoded;
      headers['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8';
    }

    return { url, method, headers, body };
  }

  async function fetchWithTimeout(url, options, timeoutMs) {
    const controller = typeof AbortController === 'function' ? new AbortController() : null;
    const timer = controller
      ? window.setTimeout(() => controller.abort(), timeoutMs)
      : null;

    try {
      return await fetch(url, {
        ...options,
        credentials: 'include',
        cache: 'no-store',
        redirect: 'follow',
        referrer: location.href,
        signal: controller ? controller.signal : undefined
      });
    } finally {
      if (timer) window.clearTimeout(timer);
    }
  }

  async function performRequest(requestId, descriptor, timeoutMs, mode) {
    try {
      const response = await fetchWithTimeout(
        descriptor.url.href,
        {
          method: descriptor.method,
          headers: descriptor.headers,
          body: descriptor.body
        },
        timeoutMs
      );
      const text = (await response.text()).slice(0, MAX_RESPONSE_CHARS);
      emitResult({
        requestId,
        mode,
        ok: response.ok,
        status: response.status,
        responseUrl: response.url,
        text
      });
    } catch (error) {
      emitResult({
        requestId,
        mode,
        ok: false,
        status: 0,
        responseUrl: descriptor.url.href,
        timedOut: error && error.name === 'AbortError',
        error: error && error.message ? error.message : String(error)
      });
    }
  }

  function submitFormDirect(form, submitter) {
    const request = consumeDirectRequest();
    if (!request) return false;

    try {
      const descriptor = buildFormRequest(form, submitter || request.action);
      performRequest(request.requestId, descriptor, request.timeoutMs, 'submit');
    } catch (error) {
      emitResult({
        requestId: request.requestId,
        mode: 'submit',
        ok: false,
        status: 0,
        responseUrl: location.href,
        error: error && error.message ? error.message : String(error)
      });
    }
    return true;
  }

  function submitAnchorDirect(anchor) {
    const request = consumeDirectRequest();
    if (!request) return false;
    const url = sameOriginUrl(anchor.href);
    if (!url || /^javascript:/i.test(anchor.getAttribute('href') || '')) {
      emitResult({
        requestId: request.requestId,
        mode: 'submit',
        ok: false,
        status: 0,
        responseUrl: location.href,
        error: '无法解析网站生成的选课地址，将改用页面状态确认。'
      });
      return false;
    }

    performRequest(request.requestId, {
      url,
      method: 'GET',
      headers: { Accept: 'text/html,application/xhtml+xml,*/*;q=0.8' },
      body: undefined
    }, request.timeoutMs, 'submit');
    return true;
  }

  document.addEventListener(ARM_EVENT, armConfirmation);

  document.addEventListener(DIRECT_SUBMIT_EVENT, event => {
    const action = event.target;
    if (!action || typeof action.getAttribute !== 'function') return;

    const requestId = action.getAttribute(REQUEST_ID_ATTRIBUTE);
    if (!requestId) return;

    if (activeDirectRequest && activeDirectRequest.guardTimer) {
      window.clearTimeout(activeDirectRequest.guardTimer);
    }

    const rawTimeout = Number(action.getAttribute(REQUEST_TIMEOUT_ATTRIBUTE));
    const timeoutMs = Number.isFinite(rawTimeout)
      ? Math.min(180000, Math.max(10000, rawTimeout))
      : 45000;

    activeDirectRequest = {
      requestId,
      action,
      timeoutMs,
      consumed: false,
      guardTimer: null
    };

    armConfirmation();
    activeDirectRequest.guardTimer = window.setTimeout(() => {
      const request = consumeDirectRequest();
      if (!request) return;

      const form = typeof action.closest === 'function' ? action.closest('form') : null;
      if (form) {
        activeDirectRequest = request;
        request.consumed = false;
        submitFormDirect(form, action);
        return;
      }

      emitResult({
        requestId: request.requestId,
        mode: 'submit',
        ok: false,
        status: 0,
        responseUrl: location.href,
        triggered: true,
        error: '网站动作已触发，但未捕获到表单提交，将轮询页面状态。'
      });
    }, 120);

    try {
      action.click();
    } catch (error) {
      const request = consumeDirectRequest();
      emitResult({
        requestId: requestId,
        mode: 'submit',
        ok: false,
        status: 0,
        responseUrl: location.href,
        error: error && error.message ? error.message : String(error)
      });
    }
  });

  document.addEventListener('submit', event => {
    if (!activeDirectRequest || activeDirectRequest.consumed) return;
    const form = event.target;
    if (!form || String(form.tagName || '').toUpperCase() !== 'FORM') return;

    event.preventDefault();
    const submitter = event.submitter || activeDirectRequest.action;
    window.queueMicrotask(() => submitFormDirect(form, submitter));
  });

  document.addEventListener('click', event => {
    if (!activeDirectRequest || activeDirectRequest.consumed) return;
    const action = activeDirectRequest.action;
    if (event.target !== action && !(action.contains && action.contains(event.target))) return;

    const anchor = typeof action.closest === 'function' ? action.closest('a[href]') : null;
    if (!anchor || /^javascript:/i.test(anchor.getAttribute('href') || '')) return;
    if (!sameOriginUrl(anchor.href)) return;

    event.preventDefault();
    window.queueMicrotask(() => submitAnchorDirect(anchor));
  });

  if (typeof HTMLFormElement !== 'undefined') {
    const nativeSubmit = HTMLFormElement.prototype.submit;
    HTMLFormElement.prototype.submit = function (...args) {
      if (activeDirectRequest && !activeDirectRequest.consumed) {
        submitFormDirect(this, activeDirectRequest.action);
        return;
      }
      return nativeSubmit.apply(this, args);
    };
  }

  document.addEventListener(DIRECT_POLL_EVENT, event => {
    let command;
    try {
      const carrier = event.target;
      const payload = carrier && typeof carrier.getAttribute === 'function' &&
        carrier.getAttribute(BRIDGE_PAYLOAD_ATTRIBUTE) === 'command'
        ? carrier.textContent
        : event.detail;
      command = JSON.parse(payload || '{}');
    } catch (_) {
      return;
    }
    if (!command.requestId) return;

    const url = sameOriginUrl(command.url || location.href);
    if (!url) {
      emitResult({
        requestId: command.requestId,
        mode: 'poll',
        ok: false,
        status: 0,
        responseUrl: location.href,
        error: '确认轮询地址不是 MIS 同源地址。'
      });
      return;
    }

    const rawTimeout = Number(command.timeoutMs);
    const timeoutMs = Number.isFinite(rawTimeout)
      ? Math.min(30000, Math.max(3000, rawTimeout))
      : 10000;
    performRequest(command.requestId, {
      url,
      method: 'GET',
      headers: { Accept: 'text/html,application/xhtml+xml,*/*;q=0.8' },
      body: undefined
    }, timeoutMs, 'poll');
  });
})();
