(() => {
  'use strict';
  const HOME = '/mis/student/as/home.do';
  const ADD = '/mis/student/as/addSubject.do';
  const PENDING_KEY = 'bnbu-adddrop-pending-v1';
  const MAX_PAGES = 10;
  const COURSE_CODE = /^[A-Z]{2,12}\d{3,10}$/;
  const norm = value => String(value || '').replace(/\s+/g, ' ').trim().toUpperCase();
  const nameNorm = value => norm(String(value || '').normalize('NFKC'));
  const courseName = title => nameNorm(String(title || '').replace(/[（(]\s*\d{4}\s*[)）]\s*$/, ''));
  const isPage = value => {
    try {
      const url = new URL(value);
      return url.protocol === 'https:' && !url.port &&
        ['mis.bnbu.edu.cn', 'mis.uic.edu.cn'].includes(url.hostname) &&
        [HOME, ADD].includes(url.pathname);
    } catch (_) { return false; }
  };

  function groupsFor(raw) {
    const groups = new Map();
    for (const line of String(raw || '').split(/\r?\n/)) {
      if (!line.trim() || line.trim().startsWith('#')) continue;
      const raw = line.trim();
      // Commas may be part of a course name. Keep comma syntax only for legacy codes.
      const legacy = raw.match(/^([A-Za-z]{2,12}\d{3,10})\s*[,，]\s*(\d{4})$/);
      const parts = raw.includes('|') ? raw.split(/\s*\|\s*/) : legacy ? [legacy[1], legacy[2]] : [raw];
      const query = String(parts[0] || '').replace(/\s+/g, ' ').trim();
      const code = COURSE_CODE.test(norm(query)) ? norm(query) : null;
      const specified = norm(parts[1]);
      const section = ['', '*', '不限', '任意', 'ANY'].includes(specified) ? '' : specified;
      if (parts.length > 2 || query.length < 2 || query.length > 200 ||
          (!code && !/\p{L}/u.test(query)) || (section && !/^\d{4}$/.test(section))) {
        throw new Error('请填写课程代码或完整课程名称，可用“名称 | 1001”指定班号，不写班号表示不限班。');
      }
      const key = code ? `code:${code}` : `name:${nameNorm(query)}`;
      if (!groups.has(key)) groups.set(key, { code, query: code || query, sections: [] });
      if (!groups.get(key).sections.includes(section)) groups.get(key).sections.push(section);
    }
    if (!groups.size) throw new Error('请至少填写一个课程代码或完整课程名称。');
    return [...groups.values()];
  }

  function combinedGroup(group, groups) {
    return { ...group, sections: [...new Set(groups.filter(item => item.code === group.code).flatMap(item => item.sections))] };
  }

  function findTable(doc, registered) {
    const heading = registered ? 'LIST OF COURSES REGISTERED' : 'LIST OF COURSES FOUND';
    const matches = [...doc.querySelectorAll('table')].filter(table =>
      [...table.querySelectorAll('caption, thead th')].some(el => norm(el.textContent) === heading));
    if (matches.length !== 1) throw new Error('未能唯一识别加减课课程表，已暂停，请手动检查页面。');
    return matches[0];
  }

  function records(table) {
    return [...table.rows].filter(row => row.cells.length >= 8 && row.cells[1].tagName === 'TD').map(row => {
      const code = norm(row.cells[1].textContent);
      const title = String(row.cells[2].textContent || '').trim();
      const section = title.match(/[（(]\s*(\d{4})\s*[)）]\s*$/)?.[1] || '';
      return { row, code, title, section };
    });
  }

  function registeredState(doc, group) {
    const found = records(findTable(doc, true)).filter(row => row.code === group.code);
    if (found.some(row => group.sections.includes('') || group.sections.includes(row.section))) return 'done';
    return found.length ? 'other-section' : 'missing';
  }

  function checkedForm(doc, id, origin, permitted) {
    const form = doc.getElementById(id);
    if (!form || form.tagName !== 'FORM' || String(form.method).toUpperCase() !== 'POST') {
      throw new Error('加减课表单结构变化，已暂停。');
    }
    const action = new URL(form.getAttribute('action') || HOME, origin);
    if (action.origin !== origin || !permitted.includes(action.pathname) || action.search || action.hash) {
      throw new Error('表单目标不在允许的搜索/加课范围内，已暂停。');
    }
    return form;
  }

  function searchBody(doc, group, page, origin) {
    const form = checkedForm(doc, 'seachForm', origin, [HOME]);
    const keyword = form.elements.namedItem('keyWord');
    const type = form.elements.namedItem('keyWordType');
    const allow = form.elements.namedItem('allowType');
    const typeValue = group.code ? '7' : '1';
    const typeLabel = group.code ? 'SEARCH BY CODE' : 'SEARCH BY COURSE';
    if (!keyword || !type || !allow ||
        ![...type.options].some(o => o.value === typeValue && norm(o.textContent) === typeLabel) ||
        ![...allow.options].some(o => o.value === '1' && norm(o.textContent) === 'ALL')) {
      throw new Error('未找到对应的学校课程搜索选项，已暂停。');
    }
    const body = new URLSearchParams(new FormData(form));
    body.set('keyWord', group.code || group.query);
    body.set('keyWordType', typeValue);
    body.set('allowType', '1');
    body.set('pageIndex', String(page));
    body.set('pageSize', '50');
    return body;
  }

  function addCandidate(doc, group, origin) {
    const rows = records(findTable(doc, false));
    for (const wanted of group.sections) {
      for (const record of rows) {
        if (record.code !== group.code || (wanted && record.section !== wanted) || !record.section) continue;
        const buttons = [...record.row.cells[7].querySelectorAll('input[type="button"],button')];
        for (const button of buttons) {
          if (norm(button.value || button.textContent) !== 'ADD' || button.disabled ||
              button.getAttribute('aria-disabled') === 'true' || /\bdisabled\b/i.test(button.className)) continue;
          // Only the observed native Add handler may identify a submission.
          const match = String(button.getAttribute('onclick') || '').match(/^\s*(?:return\s+)?addSubject\(\s*(['"])([A-Za-z0-9_-]{1,100})\1\s*\)\s*;?\s*$/);
          if (!match) continue;
          const id = match[2];
          if (record.row.cells[2].id !== id || doc.getElementById(id) !== record.row.cells[2]) continue;
          const type = doc.getElementById(id + '_type');
          if (!type) throw new Error('目标课程缺少学校的课程类别字段，已暂停。');
          const limit = { 'FE/GE': ['FEGE', 6], 'FE/OW': ['FEOW', 9], 'FE/OT': ['FEOT', 6] }[norm(type.value)];
          if (limit) {
            const total = doc.getElementById(limit[0]);
            if (!total || !Number.isFinite(Number(total.value)) || Number(total.value) >= limit[1]) {
              throw new Error(`${group.code} 需要确认学校的类别学分提醒，请手动加课。`);
            }
          }
          const form = checkedForm(doc, 'frm', origin, [HOME, ADD]);
          if (!form.elements.namedItem('id') || !form.elements.namedItem('timeClash')) {
            throw new Error('加课表单缺少必要字段，已暂停。');
          }
          const body = new URLSearchParams(new FormData(form));
          if ([...body.keys()].some(key => /drop|withdraw|replace/i.test(key)) ||
              body.get('timeClash')) throw new Error('检测到非标准加课表单，已暂停。');
          body.set('id', id);
          return { code: group.code, section: record.section, body };
        }
      }
    }
    return null;
  }

  function morePages(doc, page) {
    const currentRows = records(findTable(doc, false)).length;
    const pagerScript = [...doc.scripts].map(s => s.textContent).find(text => /new\s+Pagination\s*\(/.test(text));
    const total = pagerScript?.match(/\btotal\s*:\s*(\d+)/)?.[1];
    return total === undefined ? currentRows >= 50 : page * 50 < Number(total);
  }

  function create(hooks) {
    const origin = location.origin;
    let generation = 0;
    let running = false;
    let timer = null;
    let wake = null;
    let controller = null;
    let leaseOwner = '';
    let pending = null;
    let preview = false;
    const current = token => running && token === generation && (preview || hooks.getConfig().enabled);
    const delayMs = () => {
      const min = Math.min(3600000, Math.max(500, Number(hooks.getConfig().minInterval) * 1000 || 500));
      const max = Math.min(3600000, Math.max(min, Number(hooks.getConfig().maxInterval) * 1000 || min));
      return min + Math.random() * (max - min);
    };
    const timeoutMs = () => Math.min(180000, Math.max(10000, Number(hooks.getConfig().submitTimeout) * 1000 || 10000));
    const endAt = () => hooks.getConfig().endAt ? new Date(hooks.getConfig().endAt).getTime() : Infinity;
    const lease = () => chrome.runtime.sendMessage({ type: 'as-lease', action: 'acquire', owner: leaseOwner, ttl: timeoutMs() + 5000 });

    async function sleep(ms, token) {
      if (!current(token)) return false;
      await new Promise(resolve => {
        wake = resolve;
        timer = window.setTimeout(resolve, Math.max(0, Math.min(ms, preview ? Infinity : endAt() - Date.now())));
      });
      timer = null;
      wake = null;
      return current(token);
    }

    function stop() {
      running = false;
      generation += 1;
      if (timer) window.clearTimeout(timer);
      if (wake) wake();
      if (controller) controller.abort();
      timer = null;
      wake = null;
      controller = null;
      if (leaseOwner) chrome.runtime.sendMessage({ type: 'as-lease', action: 'release', owner: leaseOwner }).catch(() => {});
    }

    function halt(message, kind = 'warn') {
      stop();
      hooks.onStop(message, kind);
      if (!preview) hooks.notify?.(kind === 'success' ? '加课完成' : '加课已暂停', message);
    }

    async function setPending(value) {
      pending = value;
      await chrome.storage.local.set({ [PENDING_KEY]: value });
    }

    async function request(path, body, token) {
      if (![HOME, ADD].includes(path) || !isPage(origin + path)) throw new Error('请求目标不在加课白名单内。');
      if (!current(token)) throw new DOMException('Stopped', 'AbortError');
      if (!preview && Date.now() >= endAt()) throw new Error('已到结束时间，监测停止。');
      const lock = await lease();
      if (!lock?.ok) throw new Error('另一个页面正在执行加课，请只在一个页面运行。');
      if (!current(token)) throw new DOMException('Stopped', 'AbortError');
      if (!preview && Date.now() >= endAt()) throw new Error('已到结束时间，监测停止。');
      const active = new AbortController();
      controller = active;
      const timeout = window.setTimeout(() => active.abort(), Math.min(timeoutMs(), preview ? Infinity : endAt() - Date.now()));
      try {
        const response = await fetch(origin + path, {
          method: body ? 'POST' : 'GET', body,
          credentials: 'same-origin', redirect: 'follow', cache: 'no-store',
          headers: { Accept: 'text/html' }, signal: active.signal
        });
        const text = await response.text();
        if (!current(token)) throw new DOMException('Stopped', 'AbortError');
        const url = new URL(response.url || origin + path);
        if (/login|logout/i.test(url.pathname) || response.status === 401 || response.status === 403) {
          throw new Error('MIS 登录已失效，请重新登录后再开始。');
        }
        if (!response.ok) throw new Error(`学校服务器返回 HTTP ${response.status}，请稍后重试。`);
        if (url.origin !== origin || ![HOME, ADD].includes(url.pathname)) throw new Error('服务器返回了未知页面，已暂停。');
        if (text.length > 2000000) throw new Error('服务器页面过大，已暂停。');
        const doc = new DOMParser().parseFromString(text, 'text/html');
        if (doc.querySelector('input[type="password"]')) throw new Error('MIS 登录已失效，请重新登录后再开始。');
        return doc;
      } finally {
        window.clearTimeout(timeout);
        if (controller === active) controller = null;
      }
    }

    async function verifyPending(token) {
      if (!pending) return null;
      if (pending.origin !== origin || !pending.code || !pending.section) {
        throw new Error('存在其他域名的待确认加课，请先手动核对选课结果。');
      }
      const group = { code: pending.code, sections: [pending.section] };
      const deadline = Date.now() + timeoutMs();
      do {
        hooks.setStatus(`正在确认 ${pending.code} | ${pending.section}，不会重复提交。`);
        const doc = await request(HOME, null, token);
        if (registeredState(doc, group) === 'done') {
          await setPending(null);
          return doc;
        }
        if (!await sleep(delayMs(), token)) return null;
      } while (Date.now() < deadline && current(token));
      if (current(token)) throw new Error('未能确认上次加课结果，已暂停以免重复提交。请先到 MIS 核对，再点击弹窗中的“已核对结果，解除暂停”。');
      return null;
    }

    async function search(doc, group, page, token) {
      const body = searchBody(doc, group, page, origin);
      for (let attempt = 0; attempt < 3; attempt += 1) {
        try { return await request(HOME, body, token); }
        catch (error) {
          if (!current(token)) throw error;
          const transient = error.name === 'AbortError' || /HTTP (429|5\d\d)/.test(error.message);
          if (!transient || attempt === 2 || (!preview && Date.now() >= endAt())) throw error;
          hooks.setStatus(`搜索暂未完成，稍后重试 ${group.code || group.query}。`, 'warn');
          if (!await sleep(Math.max(delayMs(), 1000 * (attempt + 1)), token)) throw error;
        }
      }
    }

    async function resolveName(doc, group, token) {
      const codes = new Set();
      let resultCount = 0;
      for (let page = 1; page <= MAX_PAGES && current(token); page += 1) {
        hooks.setStatus(`正在按名称搜索“${group.query}”，确认唯一课程后再加课。`);
        doc = await search(doc, group, page, token);
        const found = records(findTable(doc, false));
        resultCount += found.length;
        for (const record of [...records(findTable(doc, true)), ...found]) {
          if (courseName(record.title) !== nameNorm(group.query)) continue;
          if (!COURSE_CODE.test(record.code)) throw new Error('名称搜索结果的课程代码无法识别，请改填课程代码。');
          codes.add(record.code);
        }
        if (codes.size > 1) throw new Error(`“${group.query}”对应多门同名课程：${[...codes].join('、')}。请填写课程代码，脚本不会自行选择。`);
        if (!morePages(doc, page)) {
          if (!codes.size && resultCount) throw new Error(`没有与“${group.query}”完整匹配的课程。请填写 MIS 显示的完整名称或课程代码。`);
          return { doc, code: [...codes][0] || null };
        }
        if (page === MAX_PAGES) throw new Error('名称搜索结果页数过多，无法确认唯一课程，请改填课程代码。');
        if (!await sleep(delayMs(), token)) return { doc, code: null };
      }
      return { doc, code: null };
    }

    async function run(token, groups) {
      pending = (await chrome.storage.local.get(PENDING_KEY))[PENDING_KEY] || null;
      if (!current(token)) return;
      let doc = document;
      if (pending) doc = await verifyPending(token) || doc;
      while (current(token)) {
        if (!preview && Date.now() >= endAt()) return halt('已到结束时间，监测停止。');
        const starts = hooks.getConfig().startAt ? new Date(hooks.getConfig().startAt).getTime() : 0;
        if (!preview && starts > Date.now()) {
          hooks.setStatus('已排程，等待开始自动搜索加课。');
          await sleep(Math.min(1000, starts - Date.now()), token);
          continue;
        }
        let missing = false;
        const blocked = [];
        for (const entry of groups) {
          if (!current(token)) return;
          if (!entry.code) {
            const resolved = await resolveName(doc, entry, token);
            if (!current(token)) return;
            doc = resolved.doc;
            entry.code = resolved.code;
            if (!entry.code) {
              missing = true;
              hooks.setStatus(`尚未找到“${entry.query}”，稍后继续搜索。`);
              if (!await sleep(delayMs(), token)) return;
              continue;
            }
            // Give the server the configured gap before the exact-code recheck.
            if (!await sleep(delayMs(), token)) return;
          }
          const group = combinedGroup(entry, groups);
          const state = registeredState(doc, group);
          if (state === 'done') continue;
          if (state === 'other-section') { blocked.push(group.code); continue; }
          missing = true;
          let best = null;
          for (let page = 1; page <= MAX_PAGES && current(token); page += 1) {
            hooks.setStatus(`正在自动搜索 ${group.code}${page > 1 ? `，第 ${page} 页` : ''}。`);
            doc = await search(doc, group, page, token);
            const latest = registeredState(doc, group);
            if (latest !== 'missing') break;
            const found = addCandidate(doc, group, origin);
            const rank = found ? group.sections.findIndex(section => !section || section === found.section) : Infinity;
            if (found && (!best || rank < best.rank)) best = { candidate: found, rank, page };
            const hasMore = morePages(doc, page);
            if (best && (best.rank === 0 || !hasMore)) {
              let candidate = best.candidate;
              if (best.page !== page) {
                // Revalidate an earlier-page fallback before using its form/token.
                if (!await sleep(delayMs(), token)) return;
                doc = await search(doc, group, best.page, token);
                if (registeredState(doc, group) !== 'missing') break;
                candidate = addCandidate(doc, group, origin);
                if (!candidate) break;
              }
              if (preview || !hooks.getConfig().autoConfirm || hooks.getConfig().directSubmit === false) {
                return halt(`已找到可加课程 ${candidate.code} | ${candidate.section}，未提交。自动加课需开启“自动确认选课”和“接口直提并确认”。`);
              }
              await setPending({ origin, code: candidate.code, section: candidate.section, time: Date.now() });
              if (!current(token)) return;
              hooks.setStatus(`正在加课 ${candidate.code} | ${candidate.section}，只提交一次并核对结果。`);
              try {
                const added = await request(ADD, candidate.body, token);
                if (registeredState(added, { code: candidate.code, sections: [candidate.section] }) === 'done') {
                  await setPending(null);
                  doc = added;
                }
              } catch (error) {
                if (!current(token)) return;
                // An interrupted POST may have committed. Verify, never blindly retry.
                hooks.setStatus('提交结果暂不明确，正在核对已注册课程。', 'warn');
              }
              if (pending && current(token)) doc = await verifyPending(token) || doc;
              break;
            }
            if (!hasMore) break;
            if (page === MAX_PAGES) throw new Error('搜索结果页数过多，请核对课程代码和班号。');
            if (!await sleep(delayMs(), token)) return;
          }
          if (!await sleep(delayMs(), token)) return;
        }
        if (!current(token)) return;
        if (groups.every(group => group.code && registeredState(doc, combinedGroup(group, groups)) === 'done')) return halt('所有目标课程已在“已注册课程”中确认，加课完成。', 'success');
        if (!missing) return halt(`以下课程已注册在其他班号：${blocked.join('、')}。脚本不会自动退课或换班，请手动处理。`);
        if (preview) return halt('检查完成，暂未找到可用 Add；未执行加课或退课。');
        hooks.setStatus('暂未找到可用名额，将继续搜索目标课程。');
      }
    }

    function start(options = {}) {
      stop();
      preview = Boolean(options.preview);
      let groups;
      try {
        if (!isPage(location.href)) throw new Error('不是支持的加减课页面。');
        groups = groupsFor(hooks.getConfig().targets);
        findTable(document, true);
        checkedForm(document, 'seachForm', origin, [HOME]);
      } catch (error) {
        hooks.onStop(error.message, 'error');
        return { ok: false, message: error.message };
      }
      running = true;
      leaseOwner = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
      const token = generation;
      run(token, groups).catch(error => {
        if (current(token)) halt(error.name === 'AbortError'
          ? '搜索请求超时或到达结束时间，已暂停。请检查网络与 MIS 状态后重试。'
          : error.message, 'error');
      });
      return { ok: true, message: '自动搜索加课已开始。' };
    }

    async function acknowledgeStopped() {
      stop();
      await setPending(null);
    }

    return { start, stop, acknowledgeStopped };
  }

  globalThis.BNBUAddDrop = { isPage, create };
})();
