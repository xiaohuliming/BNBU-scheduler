(() => {
  'use strict';
  const HOME = '/mis/student/as/home.do';
  const ADD = '/mis/student/as/addSubject.do';
  const PENDING_KEY = 'bnbu-adddrop-pending-v1';
  const MAX_PAGES = 10;
  const norm = value => String(value || '').replace(/\s+/g, ' ').trim().toUpperCase();
  const isPage = value => {
    try {
      const url = new URL(value);
      return url.protocol === 'https:' && !url.port &&
        ['mis.bnbu.edu.cn', 'mis.uic.edu.cn'].includes(url.hostname) &&
        [HOME, ADD].includes(url.pathname);
    } catch (_) { return false; }
  };

  function groupsFor(raw) {
    const groups = new Map();
    for (const line of String(raw || '').split(/\r?\n/)) {
      if (!line.trim() || line.trim().startsWith('#')) continue;
      const parts = line.trim().split(/\s*[|,，]\s*/);
      const code = norm(parts[0]);
      const section = norm(parts[1]);
      if (parts.length > 2 || !/^[A-Z]{2,12}\d{3,10}$/.test(code) ||
          (section && !/^\d{4}$/.test(section))) {
        throw new Error('加课模式请填写课程代码，班号可用“课程代码 | 1001”指定。');
      }
      if (!groups.has(code)) groups.set(code, { code, sections: [] });
      if (!groups.get(code).sections.includes(section)) groups.get(code).sections.push(section);
    }
    if (!groups.size) throw new Error('请至少填写一个课程代码。');
    return [...groups.values()];
  }

  function findTable(doc, registered) {
    const heading = registered ? 'LIST OF COURSES REGISTERED' : 'LIST OF COURSES FOUND';
    const matches = [...doc.querySelectorAll('table')].filter(table =>
      [...table.querySelectorAll('caption, thead th')].some(el => norm(el.textContent) === heading));
    if (matches.length !== 1) throw new Error('未能唯一识别加减课课程表，已暂停，请手动检查页面。');
    return matches[0];
  }

  function records(table) {
    return [...table.rows].filter(row => row.cells.length >= 8 && row.cells[1].tagName === 'TD').map(row => {
      const code = norm(row.cells[1].textContent);
      const title = String(row.cells[2].textContent || '').trim();
      const section = title.match(/[（(]\s*(\d{4})\s*[)）]\s*$/)?.[1] || '';
      return { row, code, title, section };
    });
  }

  function registeredState(doc, group) {
    const found = records(findTable(doc, true)).filter(row => row.code === group.code);
    if (found.some(row => group.sections.includes('') || group.sections.includes(row.section))) return 'done';
    return found.length ? 'other-section' : 'missing';
  }

  function checkedForm(doc, id, origin, permitted) {
    const form = doc.getElementById(id);
    if (!form || form.tagName !== 'FORM' || String(form.method).toUpperCase() !== 'POST') {
      throw new Error('加减课表单结构变化，已暂停。');
    }
    const action = new URL(form.getAttribute('action') || HOME, origin);
    if (action.origin !== origin || !permitted.includes(action.pathname) || action.search || action.hash) {
      throw new Error('表单目标不在允许的搜索/加课范围内，已暂停。');
    }
    return form;
  }

  function searchBody(doc, group, page, origin) {
    const form = checkedForm(doc, 'seachForm', origin, [HOME]);
    const keyword = form.elements.namedItem('keyWord');
    const type = form.elements.namedItem('keyWordType');
    const allow = form.elements.namedItem('allowType');
    if (!keyword || !type || !allow ||
        ![...type.options].some(o => o.value === '7' && /SEARCH BY CODE/.test(norm(o.textContent))) ||
        ![...allow.options].some(o => o.value === '1' && norm(o.textContent) === 'ALL')) {
      throw new Error('未找到学校的“Search By Code”搜索表单，已暂停。');
    }
    const body = new URLSearchParams(new FormData(form));
    body.set('keyWord', group.code);
    body.set('keyWordType', '7');
    body.set('allowType', '1');
    body.set('pageIndex', String(page));
    body.set('pageSize', '50');
    return body;
  }

  function addCandidate(doc, group, origin) {
    const rows = records(findTable(doc, false));
    for (const wanted of group.sections) {
      for (const record of rows) {
        if (record.code !== group.code || (wanted && record.section !== wanted) || !record.section) continue;
        const buttons = [...record.row.cells[7].querySelectorAll('input[type="button"],button')];
        for (const button of buttons) {
          if (norm(button.value || button.textContent) !== 'ADD' || button.disabled ||
              button.getAttribute('aria-disabled') === 'true' || /\bdisabled\b/i.test(button.className)) continue;
          // Only the observed native Add handler may identify a submission.
          const match = String(button.getAttribute('onclick') || '').match(/^\s*(?:return\s+)?addSubject\(\s*(['"])([A-Za-z0-9_-]{1,100})\1\s*\)\s*;?\s*$/);
          if (!match) continue;
          const id = match[2];
          if (record.row.cells[2].id !== id || doc.getElementById(id) !== record.row.cells[2]) continue;
          const type = doc.getElementById(id + '_type');
          if (!type) throw new Error('目标课程缺少学校的课程类别字段，已暂停。');
          const limit = { 'FE/GE': ['FEGE', 6], 'FE/OW': ['FEOW', 9], 'FE/OT': ['FEOT', 6] }[norm(type.value)];
          if (limit) {
            const total = doc.getElementById(limit[0]);
            if (!total || !Number.isFinite(Number(total.value)) || Number(total.value) >= limit[1]) {
              throw new Error(`${group.code} 需要确认学校的类别学分提醒，请手动加课。`);
            }
          }
          const form = checkedForm(doc, 'frm', origin, [HOME, ADD]);
          if (!form.elements.namedItem('id') || !form.elements.namedItem('timeClash')) {
            throw new Error('加课表单缺少必要字段，已暂停。');
          }
          const body = new URLSearchParams(new FormData(form));
          if ([...body.keys()].some(key => /drop|withdraw|replace/i.test(key)) ||
              body.get('timeClash')) throw new Error('检测到非标准加课表单，已暂停。');
          body.set('id', id);
          return { code: group.code, section: record.section, body };
        }
      }
    }
    return null;
  }

  function morePages(doc, page) {
    const currentRows = records(findTable(doc, false)).length;
    const pagerScript = [...doc.scripts].map(s => s.textContent).find(text => /new\s+Pagination\s*\(/.test(text));
    const total = pagerScript?.match(/\btotal\s*:\s*(\d+)/)?.[1];
    return total === undefined ? currentRows >= 50 : page * 50 < Number(total);
  }

  function create(hooks) {
    const origin = location.origin;
    let generation = 0;
    let running = false;
    let timer = null;
    let wake = null;
    let controller = null;
    let leaseOwner = '';
    let pending = null;
    let preview = false;
    const current = token => running && token === generation && (preview || hooks.getConfig().enabled);
    const delayMs = () => {
      const min = Math.min(3600000, Math.max(500, Number(hooks.getConfig().minInterval) * 1000 || 500));
      const max = Math.min(3600000, Math.max(min, Number(hooks.getConfig().maxInterval) * 1000 || min));
      return min + Math.random() * (max - min);
    };
    const timeoutMs = () => Math.min(180000, Math.max(10000, Number(hooks.getConfig().submitTimeout) * 1000 || 10000));
    const endAt = () => hooks.getConfig().endAt ? new Date(hooks.getConfig().endAt).getTime() : Infinity;
    const lease = () => chrome.runtime.sendMessage({ type: 'as-lease', action: 'acquire', owner: leaseOwner, ttl: timeoutMs() + 5000 });

    async function sleep(ms, token) {
      if (!current(token)) return false;
      await new Promise(resolve => {
        wake = resolve;
        timer = window.setTimeout(resolve, Math.max(0, Math.min(ms, preview ? Infinity : endAt() - Date.now())));
      });
      timer = null;
      wake = null;
      return current(token);
    }

    function stop() {
      running = false;
      generation += 1;
      if (timer) window.clearTimeout(timer);
      if (wake) wake();
      if (controller) controller.abort();
      timer = null;
      wake = null;
      controller = null;
      if (leaseOwner) chrome.runtime.sendMessage({ type: 'as-lease', action: 'release', owner: leaseOwner }).catch(() => {});
    }

    function halt(message, kind = 'warn') {
      stop();
      hooks.onStop(message, kind);
      if (!preview) hooks.notify?.(kind === 'success' ? '加课完成' : '加课已暂停', message);
    }

    async function setPending(value) {
      pending = value;
      await chrome.storage.local.set({ [PENDING_KEY]: value });
    }

    async function request(path, body, token) {
      if (![HOME, ADD].includes(path) || !isPage(origin + path)) throw new Error('请求目标不在加课白名单内。');
      if (!current(token)) throw new DOMException('Stopped', 'AbortError');
      if (!preview && Date.now() >= endAt()) throw new Error('已到结束时间，监测停止。');
      const lock = await lease();
      if (!lock?.ok) throw new Error('另一个页面正在执行加课，请只在一个页面运行。');
      if (!current(token)) throw new DOMException('Stopped', 'AbortError');
      if (!preview && Date.now() >= endAt()) throw new Error('已到结束时间，监测停止。');
      const active = new AbortController();
      controller = active;
      const timeout = window.setTimeout(() => active.abort(), Math.min(timeoutMs(), preview ? Infinity : endAt() - Date.now()));
      try {
        const response = await fetch(origin + path, {
          method: body ? 'POST' : 'GET', body,
          credentials: 'same-origin', redirect: 'follow', cache: 'no-store',
          headers: { Accept: 'text/html' }, signal: active.signal
        });
        const text = await response.text();
        if (!current(token)) throw new DOMException('Stopped', 'AbortError');
        const url = new URL(response.url || origin + path);
        if (/login|logout/i.test(url.pathname) || response.status === 401 || response.status === 403) {
          throw new Error('MIS 登录已失效，请重新登录后再开始。');
        }
        if (!response.ok) throw new Error(`学校服务器返回 HTTP ${response.status}，请稍后重试。`);
        if (url.origin !== origin || ![HOME, ADD].includes(url.pathname)) throw new Error('服务器返回了未知页面，已暂停。');
        if (text.length > 2000000) throw new Error('服务器页面过大，已暂停。');
        const doc = new DOMParser().parseFromString(text, 'text/html');
        if (doc.querySelector('input[type="password"]')) throw new Error('MIS 登录已失效，请重新登录后再开始。');
        return doc;
      } finally {
        window.clearTimeout(timeout);
        if (controller === active) controller = null;
      }
    }

    async function verifyPending(token) {
      if (!pending) return null;
      if (pending.origin !== origin || !pending.code || !pending.section) {
        throw new Error('存在其他域名的待确认加课，请先手动核对选课结果。');
      }
      const group = { code: pending.code, sections: [pending.section] };
      const deadline = Date.now() + timeoutMs();
      do {
        hooks.setStatus(`正在确认 ${pending.code} | ${pending.section}，不会重复提交。`);
        const doc = await request(HOME, null, token);
        if (registeredState(doc, group) === 'done') {
          await setPending(null);
          return doc;
        }
        if (!await sleep(delayMs(), token)) return null;
      } while (Date.now() < deadline && current(token));
      if (current(token)) throw new Error('未能确认上次加课结果，已暂停以免重复提交。请先到 MIS 核对，再点击弹窗中的“已核对结果，解除暂停”。');
      return null;
    }

    async function search(doc, group, page, token) {
      const body = searchBody(doc, group, page, origin);
      for (let attempt = 0; attempt < 3; attempt += 1) {
        try { return await request(HOME, body, token); }
        catch (error) {
          if (!current(token)) throw error;
          const transient = error.name === 'AbortError' || /HTTP (429|5\d\d)/.test(error.message);
          if (!transient || attempt === 2 || (!preview && Date.now() >= endAt())) throw error;
          hooks.setStatus(`搜索暂未完成，稍后重试 ${group.code}。`, 'warn');
          if (!await sleep(Math.max(delayMs(), 1000 * (attempt + 1)), token)) throw error;
        }
      }
    }

    async function run(token, groups) {
      pending = (await chrome.storage.local.get(PENDING_KEY))[PENDING_KEY] || null;
      if (!current(token)) return;
      let doc = document;
      if (pending) doc = await verifyPending(token) || doc;
      while (current(token)) {
        if (!preview && Date.now() >= endAt()) return halt('已到结束时间，监测停止。');
        const starts = hooks.getConfig().startAt ? new Date(hooks.getConfig().startAt).getTime() : 0;
        if (!preview && starts > Date.now()) {
          hooks.setStatus('已排程，等待开始自动搜索加课。');
          await sleep(Math.min(1000, starts - Date.now()), token);
          continue;
        }
        let missing = false;
        const blocked = [];
        for (const group of groups) {
          if (!current(token)) return;
          const state = registeredState(doc, group);
          if (state === 'done') continue;
          if (state === 'other-section') { blocked.push(group.code); continue; }
          missing = true;
          let best = null;
          for (let page = 1; page <= MAX_PAGES && current(token); page += 1) {
            hooks.setStatus(`正在自动搜索 ${group.code}${page > 1 ? `，第 ${page} 页` : ''}。`);
            doc = await search(doc, group, page, token);
            const latest = registeredState(doc, group);
            if (latest !== 'missing') break;
            const found = addCandidate(doc, group, origin);
            const rank = found ? group.sections.findIndex(section => !section || section === found.section) : Infinity;
            if (found && (!best || rank < best.rank)) best = { candidate: found, rank, page };
            const hasMore = morePages(doc, page);
            if (best && (best.rank === 0 || !hasMore)) {
              let candidate = best.candidate;
              if (best.page !== page) {
                // Revalidate an earlier-page fallback before using its form/token.
                if (!await sleep(delayMs(), token)) return;
                doc = await search(doc, group, best.page, token);
                if (registeredState(doc, group) !== 'missing') break;
                candidate = addCandidate(doc, group, origin);
                if (!candidate) break;
              }
              if (preview || !hooks.getConfig().autoConfirm || hooks.getConfig().directSubmit === false) {
                return halt(`已找到可加课程 ${candidate.code} | ${candidate.section}，未提交。自动加课需开启“自动确认选课”和“接口直提并确认”。`);
              }
              await setPending({ origin, code: candidate.code, section: candidate.section, time: Date.now() });
              if (!current(token)) return;
              hooks.setStatus(`正在加课 ${candidate.code} | ${candidate.section}，只提交一次并核对结果。`);
              try {
                const added = await request(ADD, candidate.body, token);
                if (registeredState(added, { code: candidate.code, sections: [candidate.section] }) === 'done') {
                  await setPending(null);
                  doc = added;
                }
              } catch (error) {
                if (!current(token)) return;
                // An interrupted POST may have committed. Verify, never blindly retry.
                hooks.setStatus('提交结果暂不明确，正在核对已注册课程。', 'warn');
              }
              if (pending && current(token)) doc = await verifyPending(token) || doc;
              break;
            }
            if (!hasMore) break;
            if (page === MAX_PAGES) throw new Error('搜索结果页数过多，请核对课程代码和班号。');
            if (!await sleep(delayMs(), token)) return;
          }
          if (!await sleep(delayMs(), token)) return;
        }
        if (!current(token)) return;
        if (groups.every(group => registeredState(doc, group) === 'done')) return halt('所有目标课程已在“已注册课程”中确认，加课完成。', 'success');
        if (!missing) return halt(`以下课程已注册在其他班号：${blocked.join('、')}。脚本不会自动退课或换班，请手动处理。`);
        if (preview) return halt('检查完成，暂未找到可用 Add；未执行加课或退课。');
        hooks.setStatus('暂未找到可用名额，将继续按课程代码搜索。');
      }
    }

    function start(options = {}) {
      stop();
      preview = Boolean(options.preview);
      let groups;
      try {
        if (!isPage(location.href)) throw new Error('不是支持的加减课页面。');
        groups = groupsFor(hooks.getConfig().targets);
        findTable(document, true);
        checkedForm(document, 'seachForm', origin, [HOME]);
      } catch (error) {
        hooks.onStop(error.message, 'error');
        return { ok: false, message: error.message };
      }
      running = true;
      leaseOwner = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
      const token = generation;
      run(token, groups).catch(error => {
        if (current(token)) halt(error.name === 'AbortError'
          ? '搜索请求超时或到达结束时间，已暂停。请检查网络与 MIS 状态后重试。'
          : error.message, 'error');
      });
      return { ok: true, message: '自动搜索加课已开始。' };
    }

    async function acknowledgeStopped() {
      stop();
      await setPending(null);
    }

    return { start, stop, acknowledgeStopped };
  }

  globalThis.BNBUAddDrop = { isPage, create };
})();
