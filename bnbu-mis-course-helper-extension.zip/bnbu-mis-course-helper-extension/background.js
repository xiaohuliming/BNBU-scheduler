chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.type !== 'notify') return;

  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icon128.png',
    title: String(message.title || '抢课脚本'),
    message: String(message.text || '')
  }).then(() => sendResponse({ ok: true }))
    .catch(error => sendResponse({ ok: false, message: error.message }));

  return true;
});
