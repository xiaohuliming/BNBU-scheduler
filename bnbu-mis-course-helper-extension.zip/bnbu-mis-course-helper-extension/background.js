chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.type !== 'notify') return;

  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icon128.png',
    title: String(message.title || '抢课脚本'),
    message: String(message.text || '')
  }).then(() => sendResponse({ ok: true }))
    .catch(error => sendResponse({ ok: false, message: error.message }));

  return true;
});

// Serialize lease changes so only one add-course tab can send requests at a time.
let leaseQueue = Promise.resolve();
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== 'as-lease') return;
  leaseQueue = leaseQueue.then(async () => {
    const url = new URL(sender.url || 'about:blank');
    if (!Number.isInteger(sender.tab?.id) || url.protocol !== 'https:' || url.port ||
        !['mis.bnbu.edu.cn', 'mis.uic.edu.cn'].includes(url.hostname) ||
        !['/mis/student/as/home.do', '/mis/student/as/addSubject.do'].includes(url.pathname) ||
        typeof message.owner !== 'string' || message.owner.length > 100) return { ok: false };
    const key = 'bnbu-adddrop-lease-v1';
    const stored = (await chrome.storage.session.get(key))[key];
    if (message.action === 'release') {
      if (stored?.tabId === sender.tab.id && stored?.owner === message.owner) await chrome.storage.session.remove(key);
      return { ok: true };
    }
    if (message.action !== 'acquire') return { ok: false };
    if (stored && stored.tabId !== sender.tab.id && stored.expires > Date.now()) {
      let alive = true;
      try { await chrome.tabs.get(stored.tabId); } catch (_) { alive = false; }
      if (alive) return { ok: false };
    }
    const ttl = Math.min(185000, Math.max(20000, Number(message.ttl) || 20000));
    await chrome.storage.session.set({ [key]: { tabId: sender.tab.id, owner: message.owner, expires: Date.now() + ttl } });
    return { ok: true };
  }).then(sendResponse).catch(() => sendResponse({ ok: false }));
  return true;
});
